TT <- function(a, b = NULL) {
    if(is.null(b)) {
        stopifnot(a)
    } else {
        stopifnot(identical(a, b))
    }
}


## Simulate GUI user password by overwriting .pwdlg()
PASS <- "qwerty1@"
ttenv <- new.env()
ttenv$p <- PASS
ttenv$.pwdlg <- function(prompt, mask, pwdesc) p
environment(ttenv$.pwdlg) <- ttenv
environment(pwset) <- ttenv
environment(pwget) <- ttenv
tfile <- tempfile()

## pwset plain
upass <- pwset(pfile = tfile, penv = e <- new.env(), hash = FALSE)
TT(upass, passcode(PASS))
TT(e$pcode, readSecret(tfile))
TT(rawToChar(secretr.open(e$pcode)), PASS)
TT(file.remove(tfile))

## pwset hash
upass <- pwset(pfile = tfile, penv = e <- new.env(), hash = TRUE)
TT(upass, passcode(PASS, hash = TRUE))
TT(e$pcode, readSecret(tfile))
TT(secretr.open(upass), sodium::hash(charToRaw(PASS)))
TT(file.remove(tfile))

## pwget plain source
upass <- pwset(pfile = tfile, penv = e <- new.env(), hash = FALSE)
TT(pwget(pfile = tfile, penv = e, pvalue = upass))
 TT(file.remove(tfile))
  
## pwget hash source
upass <- pwset(pfile = tfile, penv = e <- new.env(), hash = TRUE)
TT(pwget(pfile = tfile, penv = e, pvalue = upass))
TT(file.remove(tfile))
  
## pwget test return type
upass <- pwset(hash = FALSE)
TT(upass, passcode(PASS))

upass <- pwset(hash = TRUE)
TT(upass, passcode(PASS, hash = TRUE))

 
## (function(foovar = 100){  .typecheck("foovar", "character numericXX")  })()
#(function(foovar = 100){  .typecheck("foovar", "character numeric")  })()
## (function(foovar = 100){  .typecheck("foovar", "abc", "When sunny")  })()
## (function(foovar = passcode(" ")){  .typecheck("foovar", "raw")  })() # not a secretr, but
#TT(is.raw(passcode(" "))) # is TRUE, is.* functions are weak
#          
## (function(foovar = 1){  .typecheck.s("foovar", "plain")  })() 
## (function(foovar = passcode(" ")){  .typecheck.s("foovar", "hash cipher")  })() 
#(function(foovar = passcode(" ")){  .typecheck.s("foovar", "plain")  })() 
