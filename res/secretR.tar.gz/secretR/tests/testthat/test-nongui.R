TT <- function(a, b = NULL) {
    if(is.null(b)) {
        stopifnot(a)
    } else {
        stopifnot(identical(a, b))
    }
}

## passcodes
TT(is.secretr(p <- passcode("xyz")))
TT(is.secretr(h <- passcode("xyz", hash = TRUE)))
TT(p, passcode(charToRaw("xyz")))
TT(h, passcode(secretr.open(h), hash = NULL))

## ciphers
TT(is.secretr(c <- cipher("hello", passcode("xyz"))))
TT(!identical(c, cipher("hello", passcode("xyz", hash = TRUE))))
TT(is.raw(n <- secretr.nonce(c)))
TT(length(n <- secretr.nonce(c)) == 24)
TT(c, cipher("hello", passcode("xyz", hash = TRUE), n))
TT(n,  secretr.nonce(cipher("hello", passcode("xyz"), n)))
TT(cipher("hello", passcode("xyz"), n), cipher("hello", passcode("xyz", hash = TRUE), n))

## cipher.man 
TT(c, cipher.man(secretr.open(c), secretr.nonce(c)))
TT(is.secretr(c <- cipher("hello", passcode("xyz"))))
TT(is.raw(e <- .secretr2raw(c)))     # non exp
TT(is.raw(n <- secretr.nonce(c)))    
TT(c, cipher.man(e, n))

## secretr.open
TT(is.secretr(c <- cipher("hello", passcode("xyz"))))
TT(secretr.open(c, passcode("xyz"), human = TRUE) == "hello")
TT(is.secretr(c <- cipher("hello", passcode("xyz", hash = TRUE))))
TT(secretr.open(c, passcode("xyz"), human = TRUE)  == "hello")
TT(secretr.open(c, passcode("xyz")) == charToRaw("hello"))
TT(secretr.open(c), .secretr2raw(c))    # non exp 
                
## is.secretr 
TT(is.secretr(passcode("xyz")))
TT(is.secretr(passcode("xyz", hash = TRUE)))
TT(is.secretr(cipher("hello", passcode("xyz"))))
TT(is.secretr(cipher("hello", passcode("xyz", hash = TRUE))))

## secretr.type
TT(secretr.type(passcode("xyz")) == 'plain')
TT(secretr.type(passcode("xyz", hash = TRUE)) == 'hash')
TT(secretr.type(cipher("hello", passcode("xyz"))) == 'cipher')

## secretr.nonce
TT(identical(secretr.nonce(c <- cipher("hello", passcode("xyz"))), attr(c, "nonce")))

## .secretr2raw NOT exported
p <- passcode("hello")
TT(identical(sodium::hash(p), .secretr2raw(secretr.hashing(p)))) 
TT(is.raw(.secretr2raw(p <- passcode("xyz"))))
TT(is.raw(.secretr2raw(cipher("hello", p))))
TT(is.raw(.secretr2raw(cipher("hello", p), nonce = TRUE)))

## writeSecret
c <- cipher("hello", passcode("xyz"))
t <- tempfile()
writeSecret(c, "t")
TT(file.exists("t"))
TT(file.remove("t"))
 
p <- passcode("xyz")
t <- tempfile()
writeSecret(p, "t")
TT(is.secretr(f <- readSecret("t")))
TT(identical(f, p))
TT(file.remove("t"))
 
h <- passcode("xyz", hash = TRUE)
t <- tempfile()
writeSecret(h, "t")
TT(is.secretr(f <- readSecret("t")))
TT(identical(f, h))
TT(file.remove("t"))
 
c <- cipher("hello", passcode("xyz"))
t <- tempfile()
writeSecret(c, "t")
TT(is.secretr(f <- readSecret("t")))
TT(identical(f, c))
TT(file.remove("t"))

## pwpolicy
## default: min = 8, min.alpha = 1, min.digit = 1, min.sym = 1, US chars
TT(  pwpolicy.check("qwerty1@")) # 8 chars
TT(! pwpolicy.check("qwertya@"))
TT(! pwpolicy.check("qwerty1a"))
TT(! pwpolicy.check( "werty1@")) # 7 chars

dsc <- "At least: 8 total chars and 1 letter, from a US keyboard (including spaces)."
pp <- pwpolicy(min.digit = 0, min.sym = 0, pwdesc = dsc)
TT(  pwpolicy.check("qwertyaa", pp))

m <- function(pass) { # only lower
    l <- tolower(pass) == pass
    if(!l) message("Use lowercase")
    l}
dsc <- paste(pwpolicy()$pwdesc, "\nPlus: only lowcase letters.")
pp <- pwpolicy(more = m, pwdesc = dsc)
TT(  pwpolicy.check("qwerty1@", pp))
TT(! pwpolicy.check("qwErty1@", pp))



