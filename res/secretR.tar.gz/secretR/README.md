
# secretR

<!-- badges: start -->
<!-- badges: end -->

secreteR simplifies managing secrets. Here are some things  you can do with it.

* Open popup windows to create new passwords or validate them against existing ones.
* Set password policies to make  strong passwords.
* Encrypt and decrypt messages to store them safely.
* Hash passwords to make them unusable to hackers.

To streamline the functionalites above, the package uses a dedicate class named secretr.

## Installation

You can install the development version of secretR like so:

``` r
devtools::install_github("AntonioFasano/secretR")
```

That requires devtools package.


## Usage examples

Basic examples, find more of them in the [vignette](gh-vignette.md).


``` r
library(secretR)

## Popup querying for a new password with security policy
pwdesc <- "At least 9 chars, with 1 letter and digit \nfrom US keyboard."
policy <- pwpolicy(
    min = 9, min.alpha = 1, min.digit = 1, min.sym = 0, pwdesc = pwdesc)
pass <- pwset(policy = policy) # storing only the password hash

## Popups to set/store/validate password
passfile <- tempfile()
pwset(pfile = passfile) # store hash
valid <- pwget(pfile = passfile) # validate against hash
valid # TRUE if valid

## Non-GUI password creation
pass <- passcode("xyz", hash = TRUE)
pass
#> Binary blob (hash)

## Encrypt a message
encmsg <- cipher("hello world", pass)
encmsg
#> Binary blob (cipher)

## Decrypt a message
secretr.open(encmsg, pass, human = TRUE)
#> [1] "hello world"

## Store an encrypted message 
secfile <- tempfile()
writeSecret(encmsg, secfile)

## Decrypt a stored message
encmsg <- readSecret(secfile)
secretr.open(encmsg, pass, human = TRUE)
#> [1] "hello world"
```

## Notes

This package is based on the well-known libsodium encryption library and related R packages (see dependencies file), however, there is no guarantee whatsoever. If your computer is compromised by malware, encryption will not help because, when you decrypt your secrets, the malware can steal them from memory. Similarly, if your password follows some common pattern or is somehow [easily guessable](https://en.wikipedia.org/wiki/List_of_the_most_common_passwords), such as `1q2w3e4r`, then hashing is worthless.
