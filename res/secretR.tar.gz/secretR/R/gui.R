#' GUI functions to query user passwords 
#' 
#' These functions provide a cross-platform approach to query the user for passwords using a masked input,
#' which is not standardised in the console, if at all possible.   
#' `pwset` is for initial  password setting, and requires a second confirmation input.
#' `pwget` is for later validation, hence does not require the double-user input.
#'
#' Hashes are 32-byte large and obtained from sodium package hash(). If hashing is used, the original password remains unknown.
#' If `penv` is not `NULL`, it is an environment:
#' `pwset` uses this environment to store the user input, as a secretr, in a variable named `pcode`;
#' `pwget` looks for the variable `pcode` in this environment to validate the user input.
#'
#' By default. `pwset` applies the password policy defined by [pwpolicy()].
#' See this function for the default policy and for modifying it by setting the `policy` arg.
#' 
#' If more validation args are given to `pwget`, their values should match, such that the unique value is used,
#' otherwise an error is raised.
#' If no validation arg is given, it does not occurs and the typed password is returned as secretr,
#' whose type depends on the `hash`arg.
#' When validation occurs, validation sources (which can be can be 'plain' or 'hash' secretrs) are always hashed
#' and compared with the typed password hash, therefore the default `hash = TRUE` should stay unchanged 
#' 
#' @name gui
NULL

#' @param prompt  The first prompt. Confirmation is standardised. 
#' @param penv    Optional environment to store or validate against the secretr in `pcode` var.
#' @param pfile   Optional file to store or validate the secretr.
#' @param pvalue  Plain or hash secretr to validate user password.
#' @param mask    Masking stars if `TRUE`.
#' @param policy  Policy list. See related [pwpolicy()].
#' @param hash    Hash the user password returned or stored
#' @return `pwset` returns a secretr object of type 'plain' or 'hash' depending on `hash` argument.
#' @seealso [pwpolicy()] to learn or change the default password policy. 
#' @name gui
#' @export
pwset <- function( # Interactively create a password and possibly store it in file or memory as raw or hash
                  prompt = "Enter password", # Only the first. Confirmation is standardised. 
                  penv = NULL,         # optional env to store the secretr in 'pcode' var
                  pfile = NULL,        # optional file to store the secretr
                  mask = TRUE,         # masking stars 
                  policy = pwpolicy(), # policy list. See related function.
                  hash = TRUE          # hash password
                  ) {
    
    if(!is.null(penv) && !is.environment(penv)) stop(quote(penv), " is not an environment object.")

    repeat {
        repeat {
            pass <- .pwdlg(prompt, mask = mask, pwdesc = policy$pwdesc)
            if(pwpolicy.check(pass, policy)) break
            .tryagain()
        }
        pass2 <- .pwdlg(prompt = "Please, enter the password again", mask = mask, pwdesc = "")
        if(pass ==  pass2) break
        message("The passwords do not match!")
        .tryagain()
    }

    pass <- passcode(pass, hash)

    if(!is.null(penv)) penv$pcode <-  pass
    if(!is.null(pfile)) writeSecret(pass, pfile)
    pass
}

#' @examples
#' ## To learn about the default password policy see pwpolicy().
#' \dontrun{
#' ## Ask and store as a plain secretr in a file and the variable `e$pcode`
#' e <- new.env()
#' tmp <- tempfile()
#' pwset(pfile = tmp, penv = e, hash = FALSE)
#' identical(e$pcode, readSecret(tmp))
#' secretr.open(e$pcode, human = TRUE)
#' 
#' ## The same example, but now with a hash secretr 
#' h <- pwset(pfile = tmp, penv = e, hash = TRUE)
#' identical(h, readSecret(tmp))
#' secretr.open(h)
#' 
#' ## We edit password policy with minimum 2 digits and no symbol need  
#' pp <- pwpolicy(min.digit = 2, min.sym = 0)
#' p <- pwset(pfile = tmp, penv = e, hash = FALSE, policy = pp)
#' secretr.open(p, human = TRUE)
#' 
#' ## If we enter the same password as in p, validation is passed
#' pwget(pfile = tmp, penv = e)  # T/F result
#' # Validation sources are always hashed, so don't set 'hash = FALSE'
#' 
#' ## Without validation args, it makes sense to set 'hash' arg
#' p <- pwget(hash = FALSE) 
#' identical(p, passcode("123456a!", hash = FALSE))
#' h <- pwget(hash = TRUE) 
#' identical(h, passcode("123456a!", hash = TRUE))
#' 
#' ## Cleanup
#' file.remove(tmp)
#' 
#' }
#' 
#' @return If no validation occurs, `pwget`returns the same values as `pwset`,
#' otherwise it returns the logical result of the validation.
#' @name gui
#' @export
pwget <- function( # Ask for password and possibly validate it against file or memory (hashed) values
                  prompt = "Enter password", 
                  penv = NULL,   # env storing plain or hash secretr 'pcode' var to validate user pass
                  pfile = NULL,  # file seriliasing plain or hash secretr to validate user pass
                  pvalue = NULL, # plain or hash secretr to validate user pass
                  hash = TRUE,   # hash password
                  mask = TRUE    # masking stars 
                  ) {
    
    ## Check validation sources are equals
    valds <- NULL    
    if(!is.null(pvalue)) .typecheck("pvalue", "secretr")
    if(!is.null(pfile)) valds$pfile <- readSecret(pfile) 
    if(!is.null(penv)) {
        if(!is.environment(penv)) stop("Argument 'penv' should be an environment and ", quote(penv), "is not")
        if(!exists("pcode", penv)) stop("Missing variable 'pcode' in ", quote(penv), " environment")
        valds$penv <- penv$pcode
    }
    do.valid <- !is.null(valds)
    
    ## validate unless secretrs differs 
    if(do.valid) { 
        ## No ciphers
        types <- sapply(valds, secretr.type)
        is.cipher <- valds[types %in% "cipher"]
        if(any(is.cipher)) stop(paste(names(valds)[is.cipher], collapse = ", "), " type(s) can't be cipher")

        if(!hash) stop("When validation sources are given, they are always ashed, so you can't set `hash = FALSE`")
        ## Different types
        valtype <- unique(types) 
        if(length(valtype) > 1) stop(paste(names(valds), collapse = ", "), " types are not equal.")
        
        ## Different values
        valid <- unique(lapply(valds, .secretr2raw))
        if(length(valid) > 1) stop(paste(names(valds), collapse = ", "), " values are not equal.")
        valid <- unlist(valid)

        ## Make hash secretr for validation
        valid <- passcode(valid, hash = switch(valtype, plain = TRUE, hash = NULL))
    }
    
    ## Get user pass
    pass <- .pwdlg(prompt, mask = mask)
        
    ## Validate or return pass
    if(do.valid) {
        pass <- passcode(pass, hash = TRUE)
        return(identical(pass, valid))
    }
    passcode(pass, hash = hash)
}

.pwdlg <- function(prompt = "Enter password", mask = TRUE, pwdesc = "") { # Tcl/Tk pass box with custom prompt and optional un-mask

    ## Some built-in themes: alt, clam, classic, default, xpnative
    theme <- ifelse(Sys.info()['sysname'] == "Windows", "xpnative",  "clam")
    tcltk::tcl("ttk::style", "theme", "use", theme)
  
    dlg <- tcltk::tktoplevel()
    tcltk::tkwm.title(dlg, "BloomR")
    if(Sys.info()['sysname'] == "Windows") tcltk::tkwm.iconbitmap(dlg, R.home("doc/html/favicon.ico"))
    submit <- function() tcltk::tkdestroy(dlg)

    pass.lbl <- tcltk::ttklabel(dlg, text = prompt)
    tcltk::tkgrid(pass.lbl, pady = 5)

    pass.var <- tcltk::tclVar("")
    show <- ifelse(mask, "*", "")
    pass.entry <- tcltk::ttkentry(dlg, textvariable = pass.var, show = show, width = 30)
    tcltk::tkbind(pass.entry, "<Return>", submit)
    tcltk::tkgrid(pass.entry, pady = 0)

    pwdesc.lbl <- tcltk::ttklabel(dlg, text=pwdesc)
    tcltk::tkgrid(pwdesc.lbl, padx = 10)

    submit.btn <- tcltk::ttkbutton(dlg, text="submit", command=submit)
    tcltk::tkgrid(submit.btn, pady = 12)


    tcltk::tkwm.deiconify(dlg)
    tcltk::tkfocus(pass.entry)
    tcltk::tkwait.window(dlg)
    invisible(tcltk::tclvalue(pass.var))
}


.tryagain <- function() { # Generic stop-or-go execution
    ans <- ""
    while(ans != "y" && ans != "n") ans <- readline("Try again? (y/n) ")
    if(ans == "n") stop("Stopped by user") 
}

