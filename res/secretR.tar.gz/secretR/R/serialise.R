#' Read and write secrets to files
#' 
#' `readSecret` and `writeSecret` provide a way to obtain secretr persistence by serialising them to files.
#' 
#' @param secret  A secretr object to serialise to a file 
#' @param file    Path of file to read or write
#' @return For `readSecret` the stored secretr. For `writeSecret` invisibly `NULL`.
#'
#' @name serialise
#' @export
writeSecret <- function( # Serialize secretr to a file
                       secret,  # a secretr object
                       file     # path
                       ) {

    .typecheck('secret', "secretr")
    .typecheck('file', "character")
 
    ## Map secret type
    type <- secretr.type(secret)
    types <- c("plain", "hash", "cipher")
    itype <- as.integer(factor(type, types))

    ## Somewhat random file signature 
    sign <- charToRaw("\xed\xf3\x8c\x89\xea") 
    bin <- c(sign, as.raw(itype))
    if(type == "cipher") bin <- c(bin, secretr.nonce(secret))
    bin <- c(bin, .secretr2raw(secret))
    writeBin(bin, file)

}

#' @examples
#' p <- passcode("xyz")
#' t <- tempfile()
#' writeSecret(p, t)
#' f <- readSecret(t)
#' identical(f, p)
#' file.remove(t)
#'  
#' h <- passcode("xyz", hash = TRUE)
#' t <- tempfile()
#' writeSecret(h, t)
#' f <- readSecret(t)
#' identical(f, h)
#' file.remove(t)
#'  
#' c <- cipher("hello", passcode("xyz"))
#' t <- tempfile()
#' writeSecret(c, t)
#' f <- readSecret(t)
#' identical(f, c)
#' file.remove(t)
#' 
#' @name serialise
#' @export
readSecret <- function( # Read secretr serialized to a file
                       file  # path
                       ) {

    bin <- readBin(file, raw(), file.info(file)$size)
    sign <- charToRaw("\xed\xf3\x8c\x89\xea") 
    if(! identical(sign, bin[seq_along(sign)])) stop("Input file is not a serialised secretr")

    bin <- bin[-seq_along(sign)]
    type <- c("plain", "hash", "cipher")[as.numeric(bin[1])]

    bin <- bin[-1]

    switch(type, 
           plain = passcode(bin, hash = FALSE),
           hash = passcode(bin, hash = NULL), 
           cipher = cipher.man(bin[-(1:24)], bin[1:24])
    )

}
