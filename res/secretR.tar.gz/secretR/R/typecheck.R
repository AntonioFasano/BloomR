## Type Check Helpers

.typecheck <- function( # test argname inherits one of given classes 
                       argname,    # name as character
                       classes,    # space-spearated string with class names
                       prefix = "" # Error is "prefix, varname should be..."; comma is automatic
                       ) { 
### It looks only in calling function, i.e. it dosen't look in the .GlobalEnv or in function calling a function
    
    if(!is.character(argname)) stop("'argname' should be of type character")
    argname.val <- get(argname, envir = sys.frame(-1), inherits = FALSE)
    classes <- strsplit(trimws(classes), " +")[[1]]

    if(nzchar(prefix)) prefix <- paste0(prefix, ", ")
    if(!inherits(argname.val, classes))
        stop(sprintf("%s'%s' type/class should be ", prefix, argname),
             paste(classes, collapse = " or "),
             "\n  Its current class is ", paste(class(argname.val), collapse = " "),
             "\n  Check is based on inherits(), not weakly is.*()")
}
# (function(foovar = 100){  .typecheck("foovar", "character numericXX")  })()
# (function(foovar = 100){  .typecheck("foovar", "character numeric")  })()
# (function(foovar = 100){  .typecheck("foovar", "abc", "When sunny")  })()
# (function(foovar = passcode(" ")){  .typecheck("foovar", "raw")  })() # not a secretr, but
# is.raw(passcode(" ")) # is TRUE, is.* functions are weak

.typecheck.s <- function( # test argname is a secretr of one of the given types
                         argname,    # name as character
                         types,      # space-spearated string with one or more of 'plain', 'hash', 'cipher'
                         prefix = "" # Error is "prefix, varname should be..."; comma is automatic
                         ) { 
### It looks only in calling function, i.e. it dosen't look in the .GlobalEnv or in function calling a function
 
    if(!is.character(argname)) stop("'argname' should be of type character")
    argname.val <- get(argname, envir = sys.frame(-1), inherits = FALSE)
    types <- strsplit(trimws(types), " +")[[1]]

    if(nzchar(prefix)) prefix <- paste0(prefix, ", ")
    
    if(!inherits(argname.val, "secretr"))
        stop(sprintf("%s'%s' class should be secretr", prefix, argname),
             "\n  Its current class is ", paste(class(argname.val), collapse = " "))

    thistype <- secretr.type(argname.val) 

    if(! thistype %in% types) {
        stop(sprintf("%s'%s' should be a secretr of type ", prefix, argname),
             paste(types, collapse = " or "),
             "\n  Its current type is ", thistype)
    }
}
# (function(foovar = 1){  .typecheck.s("foovar", "plain")  })() 
# (function(foovar = passcode(" ")){  .typecheck.s("foovar", "hash cipher")  })() 
# (function(foovar = passcode(" ")){  .typecheck.s("foovar", "plain")  })() 
