#' Manage secrets in R
#'
#' SecretR allows to hash passwords, encrypt/decrypt messages, and store results securely in files or memory.
#' To collect passwords from users, a GUI window is used, allowing masked input and to set strong passwords polices.
#' 
#' To this end secretR provides the class, secretr, used to represent three types of secrets:
#' 1. 'plain':  a plain text password 
#' 2. 'hash':   the hash of a plain text  password
#' 3. 'cipher': a message encrypted with a password
#' All secretrs (including plain text) are kept in memory or files in raw format.
"_PACKAGE"
