#' Password policy
#'
#' `pwpolicy()` sets a customised password policy, which can be later verified by `pwpolicy.check()`.
#' The policy is a named list whose fields are `pwpolicy` arguments.
#' The default policy requires  at least 8 characters from an US keyboard (i.e. in the ASCII range 32:126)),
#' of which at least one should be, respectively, a letter, a digit, a symbol, and you can use spaces.
#'
#' If you set these arguments, don't forget to set the policy description `pwdesc`, unless you set only the `debug` arg.
#' If you don't, you get a warning, even if you don't actually change the defaults. `pwdesc` text is not wrapped,
#' so use enough newlines ("\\n") so as to avoid gigantic dialogue windows.
#' 
#' In `charset` the values below 32, e.g. TAB, can be used to merge passwords or other meta-purposes.
#'
#' `pwpolicy()` output can be use to set  [pwset()]'s `policy` argument.
#' @param min        Minimum number of total chars.
#' @param min.alpha  Minimum number of letters.
#' @param min.digit  Minimum number of digits.
#' @param min.sym    Minimum number of symbols.
#' @param charset    Acceptable input, that is, a vector of raw characters. Current default are the US keyboard printables.
#' @param debug      If `TRUE`,  outputs more info on wrong passwords, but possibly disclosing senstitive data.
#' @param more       Callback for further checks, receiving the password and returning logical success for an accepted password.
#' @param pwdesc     The policy description. If you change it, modify this accordingly. There is no text wrapping, thus use "\\n".
#' @return `pwpolicy()`: A named list with the same names and as the function arguments.
#'
#' @examples
#' pwpolicy.check("abcdefgh") # FALSE
#' 
#' ## No minimum digits or symbols.
#' dsc <- "At least: 8 total chars and 1 letter, from a US keyboard (including spaces)."
#' (pp <- pwpolicy(min.digit = 0, min.sym = 0, pwdesc = dsc))
#' \dontrun{
#' pwset(policy = pp)}
#' pwpolicy.check("abcdefgh", pp) # TRUE
#' 
#' ## Extend accetable characters to copyright char:
#' pwpolicy.check("abcdef1©") # FALSE
#' dsc <- paste(pwpolicy()$pwdesc, "\nPlus the copyright symbol.")
#' pp <- pwpolicy(charset = c(as.raw(32:126), charToRaw("©")), pwdesc = dsc) # or
#' pp <- pwpolicy(charset = c(as.raw(32:126), as.raw(0xc2), as.raw(0xa9)), pwdesc = dsc)
#' pp
#' \dontrun{
#' pwset(policy = pp) }
#' pwpolicy.check("abcdef1©", pp) # TRUE
#'
#' ## Using the callback to allow only lower case letters:
#' pp <- pwpolicy(more = function(pass) {
#'                         l <- tolower(pass) == pass
#'                         if(!l) message("Use lowercase")
#'                         l})
#' \dontrun{
#' pwset(policy = pp) }
#' 
#' @name pwpolicy
#' @export
pwpolicy <- function( # Password policy list. Currently at least 8 US chars, one alpha, digit, sym
                     min = 8,       # minimum total chars
                     min.alpha = 1, # minimum letters
                     min.digit = 1, # minimum digits
                     min.sym = 1,   # minimum symbols
                     charset = as.raw(32:126), # acceptable input, default to US keyboard printables
                     debug = FALSE,            # more info on wrong passwords, but possibly private
                     more = NULL,   # callback for extra check receiving pass and returning logical
                     pwdesc = NULL  # Description of passwrd policy
                     ) {


    dfl <- "At least: 8 total chars, 1 letter, 1 digit, 1 symbol, from a US keyboard (including spaces)."

    used.policy <- if(is.null(pwdesc)) dfl else pwdesc 
    if(!is.null(more) && !is.function(more)) stop("'more' argument should be a function.")

    ## Forget to change default description 
    ags <- as.list(match.call())[-1]
    ags <- setdiff(names(ags), c("debug", "pwdesc"))
    if(length(ags) && is.null(pwdesc)) {
        msg <- paste0("You set the argument", ifelse(length(ags) > 1, "s ", " "))
        qags <- paste(paste0("'", ags, "'"), collapse = ", ")
        warning(paste0(msg, qags, ", without setting the description 'pwdesc'"))
    }
         
    list(min = min, min.alpha = min.alpha, min.digit = min.digit, min.sym = min.sym,
         charset = charset, debug = debug, more = more, pwdesc = used.policy)
}

#' @param pass   password in character format.
#' @param policy policy to check against.
#' @return `pwpolicy.check()`: The password compliance as a logical.
#' @name pwpolicy
#' @export
pwpolicy.check <- function( # Check password with a policy list
                     pass,               # password in character format
                     policy = pwpolicy() # policy list. See related function.
                     ) {

    errmsg <- ""

    .typecheck("pass", "character")
    
    ## Foreign chars (i.e. not legal)
    legals <- rawToChar(policy$charset)
    pp <- strsplit(c(pass, legals), "")
    frgn <- setdiff(pp[[1]], pp[[2]])    
    frgn.raw <- lapply(frgn, charToRaw)    
    if(length(frgn) > 0) {
        smsg <- "Some characters "
        dmsg <- "\nUse the pwpolicy() debug arg to print them."
        if(policy$debug) {
            dmsg <- sapply(seq_along(frgn), function(i) paste(frgn[i], frgn.raw[i]))
            smsg <- paste0("The following characters\n", paste(dmsg, collapse = "\n"), "\n")
            dmsg <- ""
        }
        message(paste0(smsg, "do not come from a U.S. keyboard layout or your policy charset. ", dmsg))
        return(FALSE)
    }

    ## Check requirements
    errmsg <-
        with(policy, {
            if     (nchar(pass)                           < min)       paste(min,       "characters.")
            else if(nchar(gsub("[^[:alpha:]]", "", pass)) < min.alpha) paste(min.alpha, "letter(s).")
            else if(nchar(gsub("[^[:digit:]]", "", pass)) < min.digit) paste(min.digit, "digit(s).")
            else if(nchar(gsub("[[:alnum:]]",  "", pass)) < min.sym)   paste(min.sym,   "symbol(s).")
        })
        
    ## Errors?
    if(!is.null(errmsg)) {
        message("Please, use at least ", errmsg)
        return(FALSE)
    }
    
    if(!is.null(policy$more)) policy$more(pass) else TRUE
}
