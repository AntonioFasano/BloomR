#' Plain and hash secretr  
#' 
#' Plain secretrs are plain text passwords and hash secretrs are the hashes of hashed passwords.
#' `passcode` function is used to create both type of secretrs.
#' 
#' The term "plain text" means here that a password is not encrypted or hashed,
#' but its internal representation is in raw format, however it is possible to revert it back in human readable format.
#' Hashed passwords are obtained with the sodium package hash function and have a fixed length of 32 bytes.
#' Recall that when you set `hash = TRUE`, there is no practical way to go back to the original password.
#' 
#' @param pass  Password as character or raw, or password hash as raw.
#' @param hash  If `FALSE`, keep `pass` as plain raw; if `TRUE`, generate its hash;
#'              if  `NULL`  `pass` is assumed to be a proper hash in raw format.
#' @return A secretr of type 'plain' or 'hash'.
#'
#' (p <- passcode("xyz"))
#' (h <- passcode("xyz", hash = TRUE))
#' identical(p, passcode(charToRaw("xyz")))
#' identical(h, passcode(.secretr2raw(h), hash = NULL))
#' 
#' @export
passcode <- function( # Create a password of class secretr
                     pass,         # password as character or raw, or raw password hash   
                     hash = FALSE  # F: keep pass as plain raw; T: make hash; NULL: pass is already a hash
                     ) {
### hash is 32-byte size from sodium package hash(). If hash T, original password remains unknown.

    .typecheck("pass", "raw character")
    if(is.null(hash)) .typecheck("pass", "raw", "When 'hash' is NULL")
    if(is.character(pass)) pass <- charToRaw(pass)

    type <- if(isTRUE(hash)) {
                pass <- sodium::hash(pass)
                "hash"
            } else if(is.null(hash)) {
                "hash"
            } else  "plain"

    attr(pass, "type") <- type
    structure(pass, class = "secretr") ##  c('secretr', 'character'))
    
}

#' Cipher secretr
#' 
#' A cipher secretr is a message encrypted with a password.
#' You normally create a cipher with `cipher`, which executes the encryption for you.
#' If you want to execute the encryption yourself and store the result as a cipher secretr class, you want `cipher.man`.
#'
#' Note that a plain password is always hashed before being used to generate a cipher.
#' The encryption and password hashing are computed with the sodium package data_encrypt and hash functions.
#' A cipher consists of an encrypted message and 24-bit random nonce. Password hashes have a 32-byte size.
#'
#' By default, `cipher` generates a non-deterministic cipher, because its nonce is random.
#' Pass the `nonce` arg to obtain the same cipher for the same input message. See the examples for this.
#' If you already have the encrypted-message/nonce pair you might use `cipher.man` to generate the cipher secretr.
#' You could do this for testing and debugging purposes, as a rule you do not need to.
#' 
#' @param msg     Raw or character message to be encrypted.
#' @param pass    Plain or hash secretr use as a password.
#' @param nonce   24-byte nonce, auto-generated if the arg is `NULL`.
#' @return A cipher secretr.
#'
#' @examples
#' ## Generate a cipher 
#' cipher("hello", passcode("xyz"))
#' 
#' ## Generate your nonce or capture an existing one
#' n <- as.raw(sample(1:255, 24, replace = TRUE))
#' n <- secretr.nonce(cipher("hello", passcode("xyz")))
#'  
#' ## cipher() is non-deterministic
#' identical(cipher("hello", passcode("xyz")),
#'           cipher("hello", passcode("xyz"))) # FALSE
#'  
#' ## ... unless we pass a consistent nonce
#' identical(cipher("hello", passcode("xyz"), nonce = n),
#'           cipher("hello", passcode("xyz"), nonce = n))
#' 
#' ## Plain passwords are hashed before use
#' identical(cipher("hello", passcode("xyz"),              nonce = n),
#'           cipher("hello", passcode("xyz", hash = TRUE), nonce = n))
#' 
#' @name cipher
#' @export
cipher <- function( # Create a chiper secretr to encrypt a message
                   msg,         # raw or character message to encrypt
                   pass,        # plain or hash secretr
                   nonce = NULL # 24-byte nonce or random generated
                   ) {
### Encryption/hashing via sodium data_encrypt()/hash(). Hash and nonce length are 32 and  24 bytes.

    .typecheck('msg', "character raw")
    .typecheck.s('pass', "plain hash")
    if(is.character(msg)) msg <- charToRaw(msg)

    
    ## encryption wants a hashed password 
    type <- secretr.type(pass)
    pass <- .secretr2raw(pass)
    pass <- switch(type,
                   plain = sodium::hash(pass),
                   hash = pass)

    ## user nonce
    nonce <- if(!is.null(nonce)) {
                 if(length(nonce) != 24) stop("'nonce' should be 24-byte long")
                 nonce
             } else { sodium::random(24) }
    
    cp <- sodium::data_encrypt(msg, pass, nonce = nonce)           
    structure(cp, type = "cipher", class = "secretr")
}

#' @param enmsg    Encrypted message as raw
#' @param nonce    24 byte nonce as raw
#' 
#' @examples
#' ## Generate a manual cipher
#' c <- cipher("hello", passcode("xyz"))
#' e <- secretr.open(c)
#' n <- secretr.nonce(c)
#' identical(c, cipher.man(e, n))
#'
#' @name cipher
#' @export
cipher.man <- function( # Generate a manual cipher secretr object with a precomputed encrypted message and its nonce
                       enmsg, #  encrypted message as raw
                       nonce  # 24 byte nonce as raw
                   ) {

    .typecheck('enmsg', "raw")
    .typecheck('nonce', "raw")
    if(length(nonce) != 24) stop("'nonce' should be 24-byte long")
    attr(enmsg, 'nonce') <- nonce
    structure(enmsg, type = "cipher", class = "secretr")
}

#' Disclose the secret in a secretr
#'
#' Display the content of a secretr as-is or possibly decoding it in human-readable format
#' 
#' The print function does not print the content of secretr, it only displays its type.
#' This function can uncover it.
#'
#' By default this function displays the secret contained in a secretr as-is, in the internal raw format,
#' and this is the only possibility for hash secretrs.
#' For plain secretrs, if `human = TRUE`, the raw secret is converted in its character representation.
#' 
#' For ciphers, a decryption is attempted with ‘pass’ (which should be a plain password secretr) and,
#' if successful, the decrypted secret is displayed in raw or character format depending on ‘human’ value.
#'
#' @examples
#' c <- cipher("hello", passcode("xyz"))
#' secretr.open(c, passcode("xyz"), human = TRUE)
#' c <- cipher("hello", passcode("xyz", hash = TRUE))
#' secretr.open(c, passcode("xyz"), human = TRUE)
#' secretr.open(c, passcode("xyz"))
#' 
#' @param secretr The secretr to uncover.
#' @param pass    If `secretr` is a cipher, this is the plain password secretr to decrypt it.
#' @param human   If `TRUE`, return the content as a character format.
#' @return The secret in raw or character format, depending on `human` arg
#'          (but the latter can only be `FALSE` for hashes).
#'          For ciphers, the decrypted output or `FALSE` in case of failed decryption.
#'          Use `isFALSE`/`isTRUE` to test for un/successful decryptions.
#' 
#' @export
secretr.open <- function( # See the content of a secretr in raw or character format
                         secretr,       # the secretr to uncover 
                         pass = NULL,   # the plain password secretr, only to decrypt cipher secrets
                         human = FALSE  # If F, return a character
                       ) {
### Decryption with sodium data_decrypt()

    .typecheck("secretr", "secretr")
    type <- secretr.type(secretr)

    ## Only ciphers want a password
    if(!is.null(pass)) {
        if(type != 'cipher') stop("Your secretr is of type ", type, ", so you don't need to pass the 'pass' argument")
        .typecheck.s("pass", "plain hash")
        if(secretr.type(pass) == 'plain') pass <- secretr.hashing(pass)
    } else {
        ## Can't humanise hashes or encrypted ciphers ...
        if(human && type == 'cipher') stop("Your secretr is a cipher. Ciphers have no human readable format")
    }
    ## ... or hashes
    if(human && type == 'hash')   stop("Your secretr is a hash. Hashes have no human readable format")
        
    rawsec <- switch(type,
                  plain = .secretr2raw(secretr),
                  hash = .secretr2raw(secretr),
                  cipher = {
                      if(is.null(pass)) .secretr2raw(secretr)
                      else {
                          dec <- try(sodium::data_decrypt(secretr, pass), silent = TRUE)
                          if(inherits(dec, "try-error")) {
                              message("We are sorry to inform the decryption was unsuccessful")
                              dec <- FALSE
                          }
                          dec
                      }
                  })
    
    if(isFALSE(rawsec)) return(FALSE)
    if(human) rawToChar(rawsec) else rawsec
}

### Class helpers
#' Secretr class helpers
#'
#' Utilities to type-testing, converting and extracting elements from secretr

#' @param secretr A secretr.
#' @param x A secretr.
#' @param ... optional arguments to 'print' methods.
#' @name secretr
#' @export
print.secretr <- function(x, ...) message("Binary blob (", secretr.type(x),  ")")
.S3method("print", "secretr", print.secretr)

#' @examples
#' p <- passcode("hello")
#' is.secretr(p)
#'
#' @param object An object to test for being a secretr.
#' @return `is.secretr` returns `TRUE` if the object is a secretr, `FALSE` otherwise.  
#' @name secretr
#' @export
is.secretr <- function(object) { # Test for secretr class
    inherits(object, "secretr")
}

#' @examples
#' secretr.type(passcode("xyz"))
#' secretr.type(passcode("xyz", hash = TRUE))
#' secretr.type(cipher("hello", passcode("xyz")))
#' 
#' @return `secretr.type` returns one of 'plain', 'hash', 'cipher' depending on the secretr type or an error is raised.
#' @name secretr
#' @export
secretr.type <- function(secretr) { # Return 'plain', 'hash', 'cipher'
    .typecheck("secretr", "secretr")
    attr(secretr, "type")
}

#' @examples
#' ## Extract the nonce from a cipher
#' secretr.nonce(cipher("hello", passcode("xyz")))
#'
#' ## Each cipher as a random nonce making it unique...
#' c1 <- cipher("hello", passcode("xyz"))
#' c2 <- cipher("hello", passcode("xyz"))
#' identical(c1, c2)  # FALSE
#' ## ... unless you use your random nonce
#' my.nonce <- secretr.nonce()
#' c1 <- cipher("hello", passcode("xyz"), nonce = my.nonce)
#' c2 <- cipher("hello", passcode("xyz"), nonce = my.nonce)
#' identical(c1, c2)  # TRUE
#' 
#' @param cipher A cipher secretr.
#' @return `secretr.nonce` returns the cipher's nonce in raw format.
#' @name secretr
#' @export
secretr.nonce <- function(cipher = NULL) { # Return a cipher's nonce
    if(!is.null(cipher)) {
        .typecheck.s("cipher", 'cipher')
        attr(cipher, "nonce")
    } else {
        sodium::random(24)
    }
}

#' @examples
#' p <- passcode("hello")
#' (h <- secretr.hashing(p))
#' identical(sodium::hash(p), secretr.open(h))
#' 
#' @param pass A plain or hash secretr.
#' @return `secretr.hashing` returns a hash secretr from a non-cipher secretr,
#'          by hashing its plain text password for a plain secretr or as-is if it is already a hash secretr.
#' @name secretr
#' @export
secretr.hashing <- function(pass) { # Convert a non-cipher to a hash secretr, by hashing the password if it is a plain one
    .typecheck.s("pass", "plain hash")
    switch(secretr.type(pass),
        plain = passcode(.secretr2raw(pass), hash = TRUE),
        hash =  pass
    )
}

# @examples
# .secretr2raw(p <- passcode("xyz"))
# .secretr2raw(cipher("hello", p))
# .secretr2raw(cipher("hello", p), nonce = TRUE)
# 
# @param  nonce If `TRUE`, extracts the nonce from the cipher. Should be `NULL` for a non-cipher secretr.
# @return `.secretr2raw` returns the raw content of a secretr as-is,
#          except, in the case of ciphers, for attaching the nonce if `nonce` is `TRUE`.   
# @name secretr
# @export
.secretr2raw <- function( # Extract the secret from a secretr in raw format
                        secretr,
                        nonce = NULL # if `TRUE` attach nonce attribute to cipher secretrs 
                        ) {
    .typecheck("secretr", "secretr")
    if(!is.null(nonce) && !is.logical(nonce)) stop("'nonce' arg should be a logical or NULL")
    if(!is.null(nonce) && secretr.type(secretr) != 'cipher') stop("'nonce' arg should be set only for cipher secretrs")
    rawsec <- unclass(secretr)
    if(!isTRUE(nonce)) attr(rawsec, "nonce") <- NULL
    attr(rawsec, "type") <- NULL
    rawsec
}


# LocalWords:  secretr secretrs
