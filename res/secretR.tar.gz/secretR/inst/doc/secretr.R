## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
  )


## ----plain--------------------------------------------------------------------
library(secretR)
pass <- passcode("xyz")
pass
secretr.type(pass)
secretr.open(pass)
charToRaw("xyz")
secretr.open(pass, human = TRUE)

## ----plain.raw----------------------------------------------------------------
charToRaw("xyz")

## ----hash---------------------------------------------------------------------
phash <- passcode("xyz", hash = TRUE)
phash
secretr.type(phash)
secretr.open(phash)
charToRaw("xyz")
length(secretr.open(phash))


## ----cipher-------------------------------------------------------------------
pass <- passcode("xyz")
secretr.type(pass)
ciph <- cipher("hello", pass) 
secretr.type(ciph)
secretr.open(ciph)

## ----cipher.open--------------------------------------------------------------
secretr.open(ciph, pass = passcode("xyz")) # "hello" in raw format
secretr.open(ciph, pass = passcode("xyz"), human = TRUE)

## ----cipher.rand--------------------------------------------------------------
pass <- passcode("xyz")
c1 <- cipher("hello", pass) 
c2 <- cipher("hello", pass) 
identical(c1, c2)

## ----cipher.mynonce-----------------------------------------------------------
pass <- passcode("xyz")
mynonce <- secretr.nonce()
c1 <- cipher("hello", pass, nonce = mynonce) 
c2 <- cipher("hello", pass, nonce = mynonce)  
identical(c1, c2)

## ----cipher.getnonce----------------------------------------------------------
pass <- passcode("xyz")
c1 <- cipher("hello", pass)
c1.nonce <- secretr.nonce(c1)
c2 <- cipher("hello", pass, nonce = c1.nonce)  
identical(c1, c2)

## ----store.pass---------------------------------------------------------------
passfile <- tempfile() # use a meaningful file

pass <- passcode("xyz")
writeSecret(pass, passfile)
read <- readSecret(passfile)
identical(read, pass)

phash <- passcode("xyz")
writeSecret(phash, passfile)
read <- readSecret(passfile)
identical(read, phash)


## ----store.cipher-------------------------------------------------------------
secretfile <- tempfile() # use a meaningful file

pass <- passcode("xyz")
encmsg <- cipher("hello", pass)
writeSecret(encmsg, secretfile)
read <- readSecret(secretfile)
secretr.open(read, pass, human = TRUE)


## ----readline, eval= FALSE----------------------------------------------------
#  uname <- readline("Enter you username: ")

## ----readline.check, eval= FALSE----------------------------------------------
#  uname <- ""
#  while(!nzchar(uname)) {
#      uname <- readline("Enter you username: ")
#      message("Username can't be blank.")
#  }

## ----sgui.basic, eval = FALSE-------------------------------------------------
#  library(secretR)
#  pass <- pwset(prompt = "Please, enter a password for ...")

## ----sgui.store, eval = FALSE-------------------------------------------------
#  fooEnv <- new.env()
#  pass <- pwset(penv = fooEnv, pfile = "/path/to/foo-secret.bin")

## ----sgui.env-----------------------------------------------------------------
fooEnv <- new.env()
mypass <- NULL
f <- function(pass, penv) {
    mypass <- pwset(penv = fooEnv)
}


## ----sgui.env.hidden, include = FALSE-----------------------------------------
fooEnv$pcode <- ""

## ----sgui.env.test, eval = FALSE----------------------------------------------
#  f(mypass, fooEnv)

## ----sgui.env.test2, echo = TRUE----------------------------------------------
print(mypass)
ls(fooEnv)

## ----readline.pass, eval = FALSE----------------------------------------------
#  pass <- readline("Enter you password: ")

## ----sgui.mask, eval = FALSE--------------------------------------------------
#  pass <- pwset(mask = FALSE)

## ----sgui.test, eval = FALSE--------------------------------------------------
#  gui.hash <- pwset()
#  gui.plain <- pwset(hash = FALSE)

## ----sgui.test.hidden, include = FALSE----------------------------------------
gui.plain <- passcode("hello 2 all")
gui.hash <- passcode("hello 2 all", hash = FALSE)

## ----sgui.nohash.print--------------------------------------------------------
print(gui.plain)
secretr.open(gui.plain, human = TRUE)
plain <- passcode("hello 2 all")
identical(plain, gui.plain)  

print(gui.hash)
hash <- passcode("hello 2 all")
identical(hash, gui.hash)

## ----ppol.desc----------------------------------------------------------------
pwpolicy()$pwdesc

## ----ppol.new.desc, eval = FALSE----------------------------------------------
#  newdesc <-  "At least: 10 total chars, 1 letter, 1 digit, 1 symbol, from a US keyboard (including spaces)."
#  pass <- pwset(policy = pwpolicy(min = 10, pwdesc = newdesc))

## ----ppol.newline-------------------------------------------------------------
newdesc <-  "At least: 10 total chars, \n1 letter, 1 digit, 1 symbol, \nfrom a US keyboard (including spaces)."

## ----ppol.args----------------------------------------------------------------
args(pwpolicy)

## ----ppol.chars---------------------------------------------------------------
newdesc <-  paste("At least: 10 total chars, 1 letter, 1 digit, 1 symbol,",
                  "\nfrom a US keyboard (including the space and copyright).")

charToRaw("©")
cr.raw <- c(as.raw(0xc2), as.raw(0xa9))
newset <- c(as.raw(32:126), cr.raw)
## or faster
(newset <- c(as.raw(32:126), charToRaw("©")))

## ----ppol.chars.apply, eval = FALSE-------------------------------------------
#  pass <- pwset(policy = pwpolicy(charset = newset, pwdesc = newdesc))

## ----ppol.custom--------------------------------------------------------------
newdesc <-  paste("At least: 10 total chars, 1 letter, 1 digit, 1 symbol,",
                  "only lowercase, from a US keyboard (including spaces).",
                  sep = "\n")

polfun <- function(pass) {
    is.low <- tolower(pass) == pass
    if(!is.low) message("Please, use lowercase")
    is.low
}

newpol <- pwpolicy(more = polfun, pwdesc = newdesc)

## ----ppol.custom.apply, eval = FALSE------------------------------------------
#  pass <- pwset(policy = newpol)

## ----ggui.ask, eval = FALSE---------------------------------------------------
#  passfile <- tempfile() # use a meaningful file
#  pwset(pfile = passfile)

## ----ggui.check, eval = FALSE-------------------------------------------------
#  valid <- pwget(pfile = passfile)
#  valid

## ----ggui.many, eval = FALSE--------------------------------------------------
#  passfile <- tempfile()
#  fooEnv <- new.env()
#  pass <- pwset(penv = fooEnv, pfile = passfile)
#  
#  ## Validate against all these sources
#  valid <- pwget(penv = fooEnv, pfile = passfile, pvalue = pass)
#  valid

## ----ggui.plain, eval = FALSE-------------------------------------------------
#  pass <- pwget(prompt = "Enter password to connect to https://example.com",  hash = FALSE)

## ----ggui.plain.hidden, include = FALSE---------------------------------------
pass <- passcode("hello 2 all",  hash = FALSE)

## ----ggui.plain.enc-----------------------------------------------------------
text <- secretr.open(pass, human = TRUE)
text
text.enc <- URLencode(text, reserved = TRUE)
text.enc

## Some connect function wanting a password
## connect_func(text.enc) 

## ----cases.newpol, eval = FALSE-----------------------------------------------
#  pwdesc <- "At least 9 chars, with 1 letter and digit \nfrom US keyboard."
#  policy <- pwpolicy(
#      min = 9, min.alpha = 1, min.digit = 1, min.sym = 0, pwdesc = pwdesc)
#  pass <- pwset(policy = policy) # storing only the password hash

## ----cases.defpol-------------------------------------------------------------
## Nicely formatted
writeLines(strwrap(
    pwpolicy()$pwdesc # <- this is what you want 
  , width = 40))

## ----cases.envir, eval = FALSE------------------------------------------------
#  fooEnv <- new.env()
#  pwset(penv = fooEnv)
#  fooEnv$pcode  # storing only the password hash

## ----cases.validate, eval = FALSE---------------------------------------------
#  ## Create
#  passfile <- tempfile() # temp file is just for demo
#  pwset(pfile = passfile) # storing only the password hash
#  
#  ## Validate later
#  valid <- pwget(pfile = passfile)
#  valid # TRUE if the password is correct

## ----cases.webapi, eval = FALSE-----------------------------------------------
#  pass <- pwget(hash = FALSE)
#  text <- secretr.open(pass, human = TRUE)
#  text.enc <- URLencode(text, reserved = TRUE)
#  text.enc
#  
#  ## the website API requiring a password
#  ## api_func(text.enc)

## ----cases.encdec, eval = FALSE-----------------------------------------------
#  
#  ## Encrypt
#  mypass <- pwset()
#  encmsg <- cipher("my secret message", mypass)
#  secretr.open(encmsg) # just for the curious
#  
#  ## Decrypt
#  mypass <- pwget()
#  secretr.open(encmsg, pass = mypass, human = TRUE)
#                                          #-> "my secret message"

## ----cases.encdec.file, eval = FALSE------------------------------------------
#  ## Encrypt
#  secretfile <- tempfile() # temp file is just for demo
#  mypass <- pwset()
#  encmsg <- cipher("my secret message", mypass)
#  writeSecret(encmsg, secretfile)
#  
#  ## Decrypt
#  mypass <- pwget()
#  encmsg <-readSecret(secretfile)
#  secretr.open(encmsg, pass = mypass, human = TRUE )
#                                          #-> my secret message

## ----cases.encdec.manual------------------------------------------------------
## Encrypt
secretfile <- tempfile() # temp file is just for demo 
encmsg <- cipher("my secret message", passcode("xyz"))
writeSecret(encmsg, secretfile)

## Decrypt 
encmsg <-readSecret(secretfile)
secretr.open(encmsg, pass = passcode("xyz"), human = TRUE)                                       

