#' 
#' Formats and Style
#' 
#' Internally, pcloudr uses two formats:
#' the *full response*, which is a list  with the server response content and other relevant response parameters;
#' the *response JSON list*, which is a list version of the JSON response content, when available. 
#'  
#' Function return values are classified into two categories, functional and non-functional,
#' only the former is interesting, the latter returns invisibly the response content
#' (perhaps as a *response JSON list), unless exceptions are raised,
#'  
#' To get more more info on responses, you may use [pcloud.resp()], and you may manage exceptions in conditions with 
#' [pcloud.try()].
#'
#' 
#' **Full response**
#'  
#' Internally, pcloudr formats the server response  as a list with following three fields (elements):
#'  
#' - `ok`: `TRUE` if the returned status code is less then 400;
#' - `cnt`: response content;
#' - `code` the server status code ;
#' - `type` response type.
#'  
#' For convenience , we define this list the _full response_ because it contains most of the things
#' you may need and usually more, but full headers are missing.
#'  
#' Unless `type` is  "application/octet-stream", `cnt` is  converted to character
#' (this is going to be more refined in the future to avoid edge cases).
#'  
#' If `type` is  `application/json`, `cnt` string is converted into a _response JSON list_,
#' which is an R list version of the JSON structure more easily actionable. (See <https://arxiv.org/abs/1403.2805>).
#' Of course, we this is for simplicity, as the list represents only the response content.
#'  
#'  
#' **Response JSON list**
#' 
#' When the field `cnt` of the full response is a JSON list the actual elements are set by the API server,
#' but two elements appear to be standard:
#' `result` and `error`. If the API server reports no error,  the former is zero and the latter is missing. 
#'  
#' When pcloudr spots a non-zero `result`, it throws an exception based on `error`,
#' which in R usually translates into a `stop()` command.
#'  
#' As noted, not always the response content is JSON and hence actionable as a list.
#' This is the case, for example, when you mistype the API endpoint (and you get a 404 error),
#' or the destination is unreachable. Also. when you are downloading a binary file,
#' then the API server gives a JSON response only if there is an error.
#'  
#'  
#' **Style**
#'  
#' pcloudr functions can be divided in two categories:
#' those with *non-functional return*, which are relevant for their side effect, e.g. uploading a file;
#' those with *functional return*, which are without side effects, such as listing the content of a folder
#' or querying for the existence of filesystem object.
#'  
#' If no exception are raised: functional return consists of the relevant queried content,
#' such as the content of the file, the logical result of an existence test, etc.;
#' non-functional return is uninteresting, so the response JSON list is returned.
#'  
#' **Helpers**
#'  
#' Normally you are fine with the `cnt` field  of the full response, however, you may use [pcloud.resp()] to get the latter.
#' Most pcloudr functions  are high level in that they involve multiple request to the API server.
#' `pcloud.resp()`  can return a list of all  intermediate requests with the relevant URL parameters.
#'  
#' It is common for web functions to get errors that need to be managed in loops or conditionals construct.
#' For example you might want to try a request more times if it fails.
#' On those cases [pcloud.try()], rather than stopping the execution flow,
#' prints the stop message, for the user, and return `FALSE` for the program to act.
#'  
#'
#' @name formats
NULL

# LocalWords:  pcloudr JSON pcloud etc 
