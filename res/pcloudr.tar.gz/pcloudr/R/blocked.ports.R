noPort <- function(ports) { # Sadly no ports

    nports <- length(ports)
    msg <-
        switch(as.character(nports),
               "0" = return(),
               "1" = sprintf("\nThe local TCP communication port %s with pcCloud authorisation server is busy.", ports[1]),
               "2" = sprintf("\nThe local TCP communication ports, %s and %s, with pcCloud authorisation server are both busy.",
                             ports[1], ports[2]),
               sprintf("\nYou seem unlucky! Of the %d ports provided, none is free.", nports))
    message(msg)

    ## For Windows try findign the blocking procs, else direct to the readme
    if(.Platform$OS.type == "windows" && pwshcmd()) {
        message("Attempting to identify blocking processes...")
        if(!blockingProcs.win(ports)) message("Sorry, blocking processes not found")
    } else {
        message("See pcloudr 'Port Troubleshooting' in Readme.md for some help.")
    }
}

blockingProcs.win <- function( # Only for Windows, find whose occupying my ports
                          rports # required ports
                          ) {
      
    ## used Windows ports and procs
    uports <- pwshcmd(paste("Get-NetTCPConnection 127.0.0.1 -state listen",
                                   "| select LocalPort,OwningProcess | ConvertTo-Csv"))
    if(!uports$success) return(FALSE) else uports <- uports$value 
    procs <- pwshcmd("Get-Process | select Id, ProcessName  | ConvertTo-Csv")
    if(!procs$success) return(FALSE) else  procs <- procs$value 
  
    ## parse ports and proceses 
    procs <- utils::read.csv(text = procs[-1])
    procs <- stats::setNames(procs$ProcessName, procs$Id)
    uports <- utils::read.csv(text = uports[-1])
    uports <- stats::setNames(uports$OwningProcess, uports$LocalPort)
  
    ## required and used ports
    ruports <- stats::na.omit(uports[as.character(rports)])
    if(length(ruports) == 0) return(FALSE)   # unable to find offended ports 

    ## offending process 
    oprocs  <- stats::na.omit(procs[as.character(ruports)])
    if(length(oprocs) == 0) return(FALSE)   # unable to find offenders 

    writeLines(c("\nTry to close one of these programs/processes to free communications ports:",
                 unique(oprocs)))

    return(TRUE)
}
## r <- httpuv::startServer("127.0.0.1", 9998, list())
## s <- httpuv::startServer("127.0.0.1", 9999, list())
## r$stop(); s$stop(); 

pwshcmd <- function(cmd = FALSE) { # Call PowerShell for blockingProcs.win()
    psh <- Sys.which("PowerShell")
    if(cmd == FALSE) return(nzchar(psh))
    opts <- "-NoProfile -NonInteractive -Command"
    cmd <- paste(opts, shQuote(cmd))
    ret <- tryCatch(system2(psh, cmd, stdout = TRUE, stderr = TRUE),
                    warning = function(w) w)
    success <- !inherits(ret, "simpleWarning")
    list(success = success, value = ret)
}
