# API functions
# High level mapping of pCloud methods

#' Test Connection 
#'
#' Connects to the root folder using some connectivity tests and print statistics.
#' This makes the command slow, but potentially useful to detect problems and bottleneck.
#'
#' @return Print the results of connection tests with elapsed time and return invisibly `pcloud.root()` output. 
#' @export
pcloud.contest <- function() { # test connection slowly
    message("Testing your connection to pCloud...")
    time <- system.time(
        respcnt <- pcloud.lapi("listfolder",
                            list(folderid = 0), slow = TRUE))
    message(sprintf("%d items in root.",  nrow(respcnt$metadata$contents)))
    message(sprintf("%.1f secs elapsed.", time["elapsed"]))
    invisible(respcnt)
}

#' Manage Folders
#'
#' Functions to list and create folders.
#'
#' 
#' Folder listing functions, such as `pcloud.listfolder`, return metadata
#' which in turn have a content field which is an array of the metadata of folder's contents.
#'
#' `pcloud.narrow()` and `pcloud.root(narrow = TRUE)`, `pcloud.files(narrow = TRUE)`  give a data frame with 
#' paths, modification dates as POSIXlt classes, sizes, and, except for `pcloud.files`,
#' the logical `is.fld` column `TRUE` for folders.
#'
#' `pcloud.createfolderifnotexists` creates a folder if the folder doesn't exist or returns the existing folder's metadata.
#' 

#' @param narrow    if `TRUE` only show files' "path", "modified", "size" and folder attribute. See details.
#' @return  `pcloud.root`: the same value as `pcloud.root("/")`.
#' @name folders
#' @export
pcloud.root <- function(narrow = FALSE) { # A list representing the content of the root folder
    respcnt <- pcloud.api("listfolder", folderid = 0)
    large <- respcnt$metadata$contents
    if(narrow) large[c("name", "modified", "size")] else large
}

#' @param remote.path  the pCloud remote folder path.
#' @param folderid     the pCloud folder ID.
#' @param recursive    If is set full directory tree will be returned, which means that all directories will have contents filed.
#' @param showdeleted  if is set, deleted files and folders that can be undeleted will be displayed.
#' @param nofiles      if is set, only the folder (sub)structure will be returned.
#' @param noshares     if is set, only user's own folders and files will be displayed.
#' @return `pcloud.listfolder`: a data.frame representing the folder.
#'                            If  `recursive = TRUE`, the `contents` element links to subfolders.
#' @name folders
#' @export
pcloud.listfolder <- function( # A list representing the folder metadata with content
                              remote.path = NULL, # the pCloud remote folder path.
                              folderid    = NULL, # the pCloud folder ID (0  for root)
                              recursive	  = NULL, # if is set full directory tree will be returned
                              showdeleted = NULL, # if is set, deleted files and folders that can be undeleted will be displayed.
                              nofiles     = NULL, # if is set, only the folder (sub)structure will be returned.
                              noshares	  = NULL  # if is set, only user's own folders and files will be displayed.
                              ) { 
    
    idorpath(remote.path, folderid)
    pars <- list(
        path = remote.path,
        folderid    = folderid, 
        recursive   = recursive, 
        showdeleted = showdeleted, 
        nofiles     = nofiles, 
        noshares    = noshares        
    )
    respcnt <- pcloud.lapi("listfolder", pars)
    respcnt$metadata$contents
}

#' @return `pcloud.narrow`: a narrow version of `pcloud.listfolder()`, including only
#'         the  paths, modification time, size, and a logical folder attribute.
#'         See details for column formats.
#' @name folders
#' @export
pcloud.narrow <- function( # `pcloud.listfolder`, but in narrow format see .narrow()
                          remote.path = NULL, # the pCloud remote folder path.
                          folderid    = NULL, # the pCloud folder ID.
                          recursive   = NULL, # if is set full directory tree will be returned
                          showdeleted = NULL, # if is set, deleted files and folders that can be undeleted will be displayed.
                          nofiles     = NULL, # if is set, only the folder (sub)structure will be returned.
                          noshares    = NULL  # if is set, only user's own folders and files will be displayed.
                          ) { 

    resp <- pcloud.listfolder(
        remote.path = remote.path,
        folderid    = folderid, 
        recursive   = recursive, 
        showdeleted = showdeleted, 
        nofiles     = nofiles, 
        noshares    = noshares 
    )
    .narrow(resp)
}

.narrow <- function( # Make metadata$contents from folder listing narrow.
                          large # large format content
                          ) {
### Only paths, simple modification dates (without seconds and time zone), sizes, and is.fld column `TRUE` for folders.
                          
    narr <- large[c("path", "modified")]
    narr$modified <- pcloud.from.pctime(narr$modified)
    narr$size <- if(length(large$size)) large$size else NA
    narr$is.fld <- large$isfolder
    narr 
}

#' @return `pcloud.listfolderfiles`: if `narrow` is  `FALSE`, the same value of `pcloud.listfolder()`, but excluding folders;
#'                             if it is `TRUE`, a narrower version with the same columns as `pcloud.narrow()`, except `is.flds`.
#' @name folders
#' @export
pcloud.listfolderfiles <- function( # A listfolder version showing only files 
                             remote.path = NULL,  # the pCloud remote folder path.
                             folderid    = NULL,  # the pCloud folder ID (0  for root)
                             narrow      = FALSE  # like for pcloud.listfolder but excluding `is.flds` column. 
                              ) { 
    
    idorpath(remote.path, folderid)
    pars <- list(
        path      = remote.path,
        folderid  = folderid
    )
    respcnt <- pcloud.lapi("listfolder", pars)
    items <- respcnt$metadata$contents
    if(NROW(items) == 0) return(items)

    items <- with(items, items[isfolder != TRUE, ])
    rownames(items) <- NULL
    if(narrow) {
        x <- .narrow(items)
        x[names(x) != "is.fld"]
    }  else items    
}

#' @param namedvec  return a named vector file IDs and filenames
#' @param suffix    return filenames with file IDs and dash suffix.
#' @return `pcloud.listfolderfilesids.rec`: if `namedvec` is `TRUE`, a character vector
#'          whose names are the file IDs and values the file names; otherwise return only the file IDs;
#'          if `suffix` is `TRUE`, a vector of filenames suffixed with file IDs and a dash (e.g. `fileid-filename`),
#'           and with file IDs as names if `namedvec` is `TRUE`.
#' @name folders
#' @export
pcloud.listfolderfileids.rec <- function( # List recursively all file IDs below a given fodler.
                                         remote.path = NULL,  # the pCloud remote folder path.
                                         folderid    = NULL,  # the pCloud folder ID (0  for root)
                                         namedvec    = TRUE,  # return a named vector of fileids and filenames
                                         suffix      = FALSE  # return filenames with file IDs and dash suffix.
                             ) {

    idorpath(remote.path, folderid)
    pars <- list(
        path      = remote.path,
        folderid  = folderid,
        recursive = TRUE
    )
    respcnt <- pcloud.lapi("listfolder", pars, nosimplejson = TRUE)
    contents <- respcnt$metadata$contents
    ids <- c()
    findids <- function(folder, ids) {
        for(i in seq_along(folder)) {
            fsi <- folder[[i]]
            if(!fsi$isfolder)  {
                ## message(fsi$name, "\n") 
                ids <- c(ids, stats::setNames( fsi$name, fsi$fileid))
            } # else message(paste("\nFolder:", fsi$name, "\n"))        
            if(length(fsi[["contents"]])) ids <- c(findids(fsi$content, ids))
                                        #print(ids)
        }
        ids
    }
    id.names <- findids(contents, ids)  # c(fileid = filename, ...)
    rets <- if(namedvec) id.names else names(id.names)
    if(suffix) {
        pnames <- paste(id.names, names(id.names), sep = "-")
        rets <- stats::setNames(pnames, if(namedvec) names(id.names))
    }
    rets 
}

#' @param name name of the folder to create.
#' @return  `pcloud.createfolderifnotexists`: metadata of the newly created or existing folder.
#' @name folders
#' @export
pcloud.createfolderifnotexists <- function( # Creates a folder if the folder doesn't exist or returns the existing folder's metadata.
                                           remote.path = NULL, # the pCloud remote folder path.
                                           folderid    = NULL, # the pCloud folder ID.
                                           name	       = NULL   # name of the folder
                                           ) { 
    idorpath(remote.path, folderid)
    pars <- list(
        path      = remote.path,
        folderid  = folderid, 
        name	  = name
    )
    
    respcnt <- pcloud.lapi("createfolderifnotexists", pars)
    invisible(respcnt)
}


#' Test Items in Cloud
#'
#' `pcloud.exists.path`, `pcloud.exists.file`, `pcloud.exists.folder`
#' test for existence of a path a file and a folder respectively.
#' 
#' @param remote.path the pCloud absolute remote path
#' @return Logical success or item count as numeric

#' @name tests
#' @export
pcloud.exists.path <- function(remote.path) { # Test existence of file and folder objects

    if(remote.path == "/") return(TRUE)
    
    remote.path <- sub( "/$", "", remote.path)
    dir <- dirname(remote.path)
    if(isFALSE(list <- pcloud.listfolder(dir))) return(FALSE)
    paths <- list$path
    any(paths == remote.path)
}

#' @name tests
#' @export
pcloud.exists.folder <- function(remote.path) { # Test existence of file and folder objects

    if(remote.path == "/") return(TRUE)    

    remote.path <- sub( "/$", "", remote.path)
    dir <- dirname(remote.path)
    paths <- pcloud.listfolder(dir)$path
    if(is.null(paths)) return(FALSE)
    #if(isFALSE(list <- pcloud.listfolder(dir))) return(FALSE)
    #paths <- list$path
    are.flds <- pcloud.listfolder(dir)$isfolder
    isTRUE(are.flds[paths == remote.path])
}

#' @name tests
#' @export
pcloud.exists.file <- function(remote.path) { # Test existence of file and folder objects

    if(remote.path == "/") return(FALSE)    

    remote.path <- sub( "/$", "", remote.path)
    dir <- dirname(remote.path)
    paths <- pcloud.listfolder(dir)$path
    if(is.null(paths)) return(FALSE)
#    if(isFALSE(list <- pcloud.listfolder(dir))) return(FALSE)
    are.files <- ! pcloud.listfolder(dir)$isfolder
    isTRUE(are.files[paths == remote.path])
}


#' @param folderid the pCloud folder id (an alternative to path obtained from `pcloud.listfolder()`).
#' @name tests
#' @export
pcloud.count.items <- function( # Count number of items in a folder
                                remote.path = NULL, # remote.path the pCloud remote file path.
                                folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {     
    idorpath(remote.path, folderid)
    items <- pcloud.listfolder(remote.path = remote.path, folderid = folderid)
    NROW(items)        
}

#' @name tests
#' @export
pcloud.folder.empty <- function( # Test if a folder is empty
                                remote.path = NULL, # remote.path the pCloud remote file path.
                                folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {     
    idorpath(remote.path, folderid)
    pcloud.count.items(remote.path = remote.path, folderid = folderid) ==  0
}

#' @name tests
#' @export
pcloud.count.files <- function( # Count number of items in a folder
                                remote.path = NULL, # remote.path the pCloud remote file path.
                                folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {     
    idorpath(remote.path, folderid)
    items <- pcloud.listfolderfiles(remote.path = remote.path, folderid = folderid)
    NROW(items)
}

#' @name tests
#' @export
pcloud.count.folders <- function( # Count number of items in a folder
                                remote.path = NULL, # remote.path the pCloud remote file path.
                                folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {     
    idorpath(remote.path, folderid)
    length(stats::na.omit(pcloud.listfolder(remote.path = remote.path, folderid = folderid)$folderid))
}



#' Delete Items in Cloud
#' 
#' `pcloud.delete.file`, `pcloud.delete.folder`, and  `pcloud.delete.folderrec` functions delete files, folders, and folders recursively.
#' `pcloud.delete.folderfiles()` delete all files in a folder.
#' `pcloud.delete.foldercont()` is similar to  `pcloud.delete.folderrec()`, but preserve the container while deleting the content. 
#' 
#' 
#' @param remote.path the pCloud absolute remote path
#' @param fileid      the pCloud file id (an alternative to path obtained from `pcloud.listfolder()`)..
#' @param folderid    the pCloud folder id (an alternative to path obtained from `pcloud.listfolder()`)..

#' @return `pcloud.delete.file`: `TRUE` if deletion was successful, `FALSE` otherwise.
#' @name delete
#' @export
pcloud.delete.file <- function( # Delete file 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               fileid = NULL       # the pCloud file id (an alternative to path obtained from listfolder method).
                               ) {
    idorpath(remote.path, fileid)
    respcnt <- pcloud.api("deletefile", path = remote.path, fileid = fileid)
    isTRUE(respcnt$metadata$isdeleted)
}

#' @return `pcloud.delete.folder`: `TRUE` if deletion was successful, `FALSE` otherwise.
#' @name delete
#' @export
pcloud.delete.folder <- function( # Delete folder non-recursively 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {     
    idorpath(remote.path, folderid)
    respcnt <- pcloud.api("deletefolder", path = remote.path, folderid = folderid)
    isTRUE(respcnt$metadata$isdeleted)
}

#' @return `pcloud.delete.folderrec`: a vector with the names `delfiles` and `delfolds` for the number of deleted files and folders.
#' @name delete
#' @export
pcloud.delete.folderrec <- function( # Delete folder recursively 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {    
    idorpath(remote.path, folderid)
    respcnt <- pcloud.api("deletefolderrecursive", path = remote.path, folderid = folderid)
    list(delfiles = respcnt$deletedfiles, delfolds = respcnt$deletedfolders)
}

#' @return `pcloud.delete.folderfiles`: the number of successfully deleted files, with an error if less than available files.
#' @name delete
#' @export
pcloud.delete.folderfiles <- function(# Similar to`pcloud.delete.folderrec()`, but  delete content only and leave container folder. 
                                      remote.path = NULL, # remote.path the pCloud remote file path.
                                      folderid = NULL     # the pCloud folder id (an alt. to path obtained from listfolder method).
                               ) {    
    idorpath(remote.path, folderid)
    files <- pcloud.listfolderfiles(remote.path = remote.path, folderid = folderid)
    ids <- files$fileid
    if(length(ids) == 0) return(0)
    oks <- sum(sapply(ids, \(id) pcloud.delete.file(fileid = id)))
    err <- length(ids) -  oks
    if(err) stop(sprintf("It was not possible to delete all files in the folder. %s file(s) not deleted.", err))
    length(ids)
}

#' @return `pcloud.delete.foldercont`: a vector with the names `delfiles` and `delfolds` for the number of deleted files and folders.
#' @name delete
#' @export
pcloud.delete.foldercont <- function( # Delete folder recursively 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               folderid = NULL     # the pCloud folder id (an alternative to path obtained from listfolder method).
                               ) {    
    idorpath(remote.path, folderid)
    fold.ids <- pcloud.listfolder(remote.path = remote.path, folderid = folderid, nofiles = TRUE)$folderid
    dels <- lapply(fold.ids, \(id) pcloud.delete.folderrec(folderid = id))
    nfiles <- nfolds <- 0
    if(length(dels)) {
        nfiles <- sum(sapply(dels, `[[`, "delfiles"))
        nfolds <- sum(sapply(dels, `[[`, "delfolds"))
    }
    nfiles <- nfiles + pcloud.delete.folderfiles(remote.path = remote.path, folderid = folderid)
    list(delfiles = nfiles, delfolds = nfolds)
}


#' Copy and Rename Items in Cloud
#'
#' `pcloud.copyfile` and `pcloud.copyfolder` do what they mean. 
#' `pcloud.renamefile` and `pcloud.renamedir` work like Linux `mv` command, they can be used to rename and move a filesystem object.
#' 
#' For `pcloud.renamefile`, the renaming target can be one of `topath`, `tofolderid`, or `tofolderid/toname`.
#' If it is `tofolderid/toname` or `topath` is a file, than the file is renamed as the implied file.
#' If it is `tofolderid` or `topath` is a folder, the file is moved to the implied folder,
#' but, in this case, `topath` MUST end with a trailing slash.
#' 
#' For `pcloud.renamedir`, the renaming target can be one of `topath`, `tofolderid`, or `tofolderid/toname`.
#' If it is `tofolderid/toname` or `topath` is a non-existing folder, than the folder is renamed as the implied folder.
#' If it is `tofolderid` or `topath` is a folder, the folder is moved inside the implied folder,
#' but, in this case, `topath` MUST end with a trailing slash.
#'
#' @param remote.path the pCloud absolute remote path
#' @param fileid      the pCloud file id (an alternative to path obtained from listfolder method).
#' @param folderid    the pCloud folder id (an alternative to path obtained from listfolder method).
#' @param topath      destination path of the copied/renamed object, with a trailing slash if a folder.
#' @param tofolderid  ID of the folder to which the the object is moved.
#' @param toname      destination name of the renamed object.
#' @param noover      if `TRUE`, overwrite existing file or folder.
#' @return JSON response content invisibly.
#' 


#' @name copy
#' @export
pcloud.copyfile <- function( # Copy file 
                            remote.path = NULL, # remote.path the pCloud remote file path.
                            fileid = NULL,      # the pCloud file id (an alternative to path obtained from listfolder method).
                            topath = NULL,      # destination path of renamed file, with trailing slash if folder.
                            tofolderid = NULL,  # id of the folder to which the file is moved.
                            noover = FALSE      # if T, overwrite an existing file.
                            ) {

    idorpath(remote.path, fileid)

    pars <- list(path = remote.path,
                 fileid = fileid,
                 topath = topath,
                 tofolderid = tofolderid,
                 noover = noover 
                 )
  
    respcnt <- pcloud.lapi("copyfile", pars = pars)
    invisible(respcnt)

}

#' @name copy
#' @export
pcloud.renamefile <- function( # Rename file
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               fileid = NULL,      # the pCloud file id (an alternative to path obtained from listfolder method).
                               topath = NULL,      # destination path of renamed file, with trailing slash if folder.
                               tofolderid = NULL,  # id of the folder to which the file is moved.
                               toname = NULL       # destination name of the renamed object. 
                               ) {

    idorpath(remote.path, fileid)
    pars <- list(path = remote.path,
                 fileid = fileid,
                 topath = topath,
                 tofolderid = tofolderid,
                 toname = toname 
                 )
  
    respcnt <- pcloud.lapi("renamefile", pars = pars)
    invisible(respcnt)
}

#' @param  skipexisting    if `TRUE`, skip files that already exist.
#' @param  copycontentonly if `TRUE`, copy only the source folder's content, rather than the folder itself.
#' @name copy
#' @export
pcloud.copydir <- function( # Copy a folder
                           remote.path = NULL,     # remote.path the pCloud remote file path.
                           folderid = NULL,        # the pCloud folder id (an alternative to path obtained from listfolder method).
                           topath = NULL,          # destination path of renamed folder, with a trailing slash if afolder.
                           tofolderid = NULL,      # ID of the folder to which the directoy is moved.
                           noover = FALSE,         # if T, overwrite an existing file.
                           skipexisting = FALSE,   # If T, skip files that already exist.
                           copycontentonly = FALSE # if T, copy only the source folder's content, rather than the folder itself.
                           ) {

    idorpath(remote.path, folderid)
    pars <- list(path = remote.path,
                 folderid = folderid,
                 topath = topath,
                 tofolderid = tofolderid,
                 noover = noover,         
                 skipexisting = skipexisting,   
                 copycontentonly = copycontentonly
                 )

    respcnt <- pcloud.lapi("copyfolder", pars = pars)
    invisible(respcnt) 
}

#' @name copy
#' @export
pcloud.renamedir <- function( # Delete a folder
                             remote.path = NULL, # remote.path the pCloud remote file path.
                             folderid = NULL,    # the pCloud folder id (an alternative to path obtained from listfolder method).
                             topath = NULL,      # destination path of renamed folder, with a trailing slash if afolder.
                             tofolderid = NULL,  # ID of the folder to which the folder is moved.
                             toname = NULL       # destination name of the renamed object. 
                             ) {

    idorpath(remote.path, folderid)
    pars <- list(path = remote.path,
                 folderid = folderid,
                 topath = topath,
                 tofolderid = tofolderid,
                 toname = toname 
                 )

    respcnt <- pcloud.lapi("renamefolder", pars = pars)
    invisible(respcnt) 
}

#' Read & Write Data
#'
#' `pcloud.read()` and `pcloud.write()` read from and write to a remote pCloud file, and `pcloud.fsize` gets the size.
#' These high-level functions take care of opening and closing the file.
#' `pcloud.read.folderfiles()` and `pcloud.download.folderfiles()` read and download all file in a folder.
#' `pcloud.upload()` uploads a local file. These functions are not intended to download/upload large files.
#' 


#' @param remote.path the pCloud remote file path.
#' @param fileid      the pCloud file id (an alternative to path obtained from listfolder method).
#' @return `pcloud.fsize()`: the size in bytes of the remote file as numeric.
#' @name read-write
#' @export
pcloud.fsize <- function(
                         remote.path = NULL, # remote.path the pCloud remote file path.
                         fileid = NULL       # the pCloud file id (an alternative to path obtained from listfolder method).
                         ) {
    idorpath(remote.path, fileid)

    file.descriptor <- pcloud.open(remote.path = remote.path, fileid = fileid, flag = "O_WRITE")
    respcnt <- pcloud.api("file_size", fd = file.descriptor)    
    pcloud.close(file.descriptor) 
    as.numeric(respcnt$size)
}

#' @param count   read only count bytes.
#' @param verify  verify the download with sha256 checksum  
#' @return `pcloud.read`: the content of the remote file as 'application/octet-stream'.
#' @export
#' @name read-write
pcloud.read <- function( # read n bytes from a file 
                        remote.path = NULL,  # remote.path the pCloud remote file path.
                        fileid = NULL,       # the pCloud file id (an alternative to path obtained from listfolder method).
                        count = NULL,        # read only count bytes.
                        verify = FALSE,      # logical 
                        text = NA            # T/F: convert to text/leave raw. NA: auto detect. 
                        ) {    
    idorpath(remote.path, fileid)

    ## The code is long to avoid overhead in open/close with intermediate functions

    verified <- TRUE
    for(i in 1:2) {
        file.descriptor <- pcloud.open(remote.path = remote.path, fileid = fileid, flag = "O_WRITE")       
        if(is.null(count)) {
            respcnt <- pcloud.api("file_size", fd = file.descriptor)
            count <- as.numeric(respcnt$size)
        }

        respcnt <- pcloud.api("file_read", count = count, fd = file.descriptor)
        if(verify) {
            pcloud.sha <- pcloud.api("checksumfile", path = remote.path, fileid = fileid)$sha256
            verified <- pcloud.sha == paste0(as.character(sodium::sha256(respcnt)), collapse = "") 
        }
        pcloud.close(file.descriptor)
        if(verified) break
    } 
    
    if(!verified) stop("It was not possible to verifify the checksum of the ",
                       if(is.null(remote.path)) paste("file ID", fileid) else paste("file", remote.path))
               
    ## Return text of raw
    if(isFALSE(text)) return(respcnt)    
    canbetext <- canbetext(respcnt)
    if(isTRUE(text))
        return(if(canbetext) rawToChar(respcnt) else stop("The downloaded data can't be converted to text"))
    if(canbetext) rawToChar(respcnt) else respcnt
}

#' @param verbose  if `TRUE`. print the name of file to be processed. 
#' @return `pcloud.read.folderfiles`: a list whose element are named after the read files and values are the content of files.
#' @name read-write
#' @export
pcloud.read.folderfiles <- function( # read content of all files in a folder 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               folderid = NULL,    # the pCloud folder id (an alternative to path obtained from listfolder method).
                               verbose = FALSE     # If `TRUE` print the name of file to be processed. 
                               ) {
    idorpath(remote.path, folderid)

    files <- pcloud.listfolderfiles(remote.path = remote.path, folderid = folderid)
    ids <- files$fileid
    sizes <- files$size
    names <- files$name
    
    stats::setNames(lapply(seq_along(ids), \(id) {
        if(verbose) message("", names[id])
        pcloud.read(fileid = ids[id], count = sizes[id])
    }), names)
}

#' @param local.dir path of the folder to download files.
#' @param text      if `TRUE` save as text, else save as a binary file.
#' @return `pcloud.download.folderfiles`:  `NULL` invisibly.
#' @name read-write
#' @export
pcloud.download.folderfiles <- function( # read all files in a folder 
                               remote.path = NULL, # remote.path the pCloud remote file path.
                               folderid = NULL,    # the pCloud folder id (an alternative to path obtained from listfolder method).
                               local.dir,          # path of the folder to download files
                               text = FALSE,       # If TRUE save as text, else save as RDS file
                               verbose = TRUE
                               ) {
    idorpath(remote.path, folderid)

    files <- pcloud.listfolderfiles(remote.path = remote.path, folderid = folderid)
    ids <- files$fileid
    sizes <- files$size
    names <- files$name
    
    lapply(seq_along(ids), \(id) {
        if(verbose) message("", names[id])        
        path <- file.path(local.dir, names[id])
        cnt <- pcloud.read(fileid = ids[id], count = sizes[id])
        if(text) writeLines(cnt, path) else writeBin(cnt, path)         
    }) 
    invisible(NULL)
}


#' @param data    data to write as character or raw
#' @param verbose show length of uploaded data.
#' @return `pcloud.write`: logical success and if `verbose`, prints the byte written.
#' @name read-write
#' @export
pcloud.write <- function( # Create or truncate existing file then write data
                         data,                # data to write as character or raw
                         remote.path = NULL,  # remote.path the pCloud remote file path.
                         fileid = NULL,       # the pCloud file id (an alternative to path obtained from listfolder method).
                         verbose = FALSE      # show length of uploaded data.
                         ) {

    ## Check args
    idorpath(remote.path, fileid)
    if(!is.character(data) && !is.raw (data)) stop("'data' argument should be in raw or string" ) 
    
    file.descriptor <- pcloud.open(remote.path = remote.path, fileid = fileid, flag = "O_CREAT+O_TRUNC")

    ## Data is send always as raw
    if(is.character(data)) data <- charToRaw(data)
    curl.opt <- list(post = TRUE,  postfieldsize = length(data), postfields = data, customrequest = "PUT")
    
    respcnt <- if(length(data)) pcloud.lapi("file_write", pars = list(fd = -1), curl.opt = curl.opt)
               else list(bytes = 0)

    pcloud.close(fd = file.descriptor)
    if(length(data) != as.numeric(respcnt$bytes)) 
        stop("A problem occurred:uploaded data size differ from origina data")    
    if(verbose) message("Written ", respcnt$bytes, " bytes") 
    invisible(respcnt)
}

##pcloud.write.file <- function() { # perhaps todo but check upload methods
##    # unfinished 
##    curl::handle_setform(pcloudrEnv$handle, files = curl::form_file("/tmp/testup"))    
##    url <- paste0(req$epoint, "/file_write?access_token=", req$token, "&fd=-1")
##    resp <- curl::curl_fetch_memory(url, handle = pcloudrEnv$handle)
##    rawToChar(  resp$content)
##    pcloud.close(fd=-1)    
##}

#' @param local.path        local path of the file to send.
#' @param remote.path       the pCloud remote folder path.
#' @param folderid          the pCloud folder id (an alternative to path obtained from listfolder method).
#' @param filename          filename to give to the uploaded file.
#' @param renameifexists    if the destination file exists, uploaded file will be renamed.
#' @param curlwarn          Warn if cURL does not support filename args.
#' @return `pcloud.upload`: logical success.
#' @name read-write
#' @export
pcloud.upload <- function( # Upload file
                          local.path,             # local path of the file to send.
                          remote.path = NULL,     # the pCloud remote upload folder.
                          folderid = NULL,        # the pCloud folder id (an alternative to path from listfolder method).
                          filename = NULL,        # filename to give to the uploaded file
                          renameifexists = FALSE, # if the destination file exists, uploaded file will be renamed.
                          curlwarn = TRUE         # Warn if cURL does not support filename args.
                                ) {

    idorpath(remote.path, folderid)
    if(!is.null(filename) && utils::packageDate("curl") < "2023-02-15" && curlwarn)
        warning("Your curl package version does not support the 'filename' argument. Consider updating it.")
    
    pars <- list(path = remote.path, 
                 folderid = folderid, 
                 nopartial = TRUE,
                 renameifexists = renameifexists 
                 )
    curl.form <-
        if(utils::packageDate("curl") < "2023-02-15") 
            list(files = curl::form_file(local.path))
        else 
            list(files = curl::form_file(local.path, name = filename))
    
    respcnt <- pcloud.lapi("uploadfile", pars, curl.form = curl.form)
    invisible(respcnt)
}

pcloud.open <- function( # Open remote file and return file.descriptor
                        remote.path = NULL,  # remote.path the pCloud remote file path.
                        fileid = NULL,       # the pCloud file id (an alternative to path obtained from listfolder method).
                        flag                 # "O_WRITE", "O_CREAT", "O_EXCL", "O_TRUNC", "O_APPEND", "O_CREAT+O_TRUNC"
                        ) {
### You can use replace -1 for the descriptor of the last opened file
    
    ## Flags
    flag <- switch(flag, 
                   O_WRITE  =  0x0002, 
                   O_CREAT  =  0x0040, 
                   O_EXCL   =  0x0080, 
                   O_TRUNC  =  0x0200, 
                   O_APPEND =  0x0400,
                   "O_CREAT+O_TRUNC" = 0x0040 + 0x0200
                   )
    
    idorpath(remote.path, fileid)
    respcnt <- pcloud.api("file_open", path = remote.path, fileid = fileid, flags = flag)
    respcnt$fd
}

pcloud.close <- function( # Close remote file and return file.descriptor. Returning 0 when there is no error
                        fd  # file descriptor returned by pcloud.open, or -1 for the last 
                        ) {
    respcnt <- pcloud.api("file_close", fd = fd)
    invisible(respcnt)
}


#' Public Download Links
#'
#' Generate and download from public links.
#' 
#' `pcloud.pub.down.filelink()` generates a public link to download a pCloud file, intended for non-programmatic access,
#' via the pCloud web site.
#'
#' `pcloud.direct()` generates a temporary direct link to download a publicly shared item, intended for programmatic access.
#' To generate a direct download link to a cloud item, it is necessary
#' the item's sharing code and the endpoint associated with the account of the sharing user.
#' The sharing code is in the output list of `pcloud.pub.down.filelink()`
#' (it is also included in the website link generated by `pcloud.pub.down.filelink()`).
#' The endpoint can be obtained from [pcloud.endpoint()].
#' The duration of direct links is not specified by pCloud, but a user should generate them only when
#' they intend "to actually download the file". Luckily, provided that you have delivered both the code and the endpoint,
#' anyone can obtain a direct link, when they are about to download, without authentication.
#'
#' Typically, you are not actually interested in the (direct) file link, but rather in its content. Thus,  what you want are
#' `pcloud.read.link()` and `pcloud.down.from.plink()` respectively to read data from a public link and to download it to a file.
#' When you do not need the link any more, `pcloud.delink()` can delete it.
#'
#' `pcloud.direct()`, `pcloud.read.link()` and `pcloud.down.from.plink()` do not require authentication.
#' 
#' A convenient way to distribute sharing codes+endpoints could be to generate an encoded string including them.
#' See [pcloud.encodelink()]
#'

#' @param remote.path  the pCloud remote file path.
#' @param fileid       the pCloud file id (an alternative to path obtained from listfolder method).
#' @param expire       time when the link will stop working as POSIXt class.
#' @param maxdownloads maximum number of downloads for this file.
#' @param maxtraffic   maximum traffic in bytes that this link will consume.
#' @param shortlink    if set, a short link will also be generated
#' @param linkpassword set a password for the link.
#' @return `pcloud.pub.down.filelink`: a list of three elements:
#'        `website`, the website link for non-programmatic download;
#'        `linkid`, the numeric ID that can be used to delete/modify this public link;
#'        `code`, the sharing code to generate a direct download link;
#'        `cnt`, The entire API JSON output as a list.
#' @name public-downloads
#' @export
pcloud.pub.down.filelink <- function( # Creates and return a public link to a file. 
                        remote.path = NULL,   # the pCloud remote file path.
                        fileid = NULL,        # the pCloud file id (an alternative to path obtained from listfolder method).
                        expire = NULL,        # time when the link will stop working as POSIXt class.
                        maxdownloads = NULL,  # maximum number of downloads for this file.
                        maxtraffic = NULL,    # maximum traffic in bytes that this link will consume.
                        shortlink  = NULL,    # if set, a short link will also be generated
                        linkpassword = NULL   # set a password for the link.
                        ) { 

    idorpath(remote.path, fileid) 
    if(!is.null(expire) && !inherits(expire, "POSIXt")) stop("'expire' argument should be a POSIXt class")
    if(!is.null(expire)) expire <- pcloud.to.pctime(expire)
    pars <- list(path = remote.path,
                 fileid = fileid,
                 expire = expire,
                 maxdownloads = maxdownloads,
                 maxtraffic = maxtraffic,
                 shortlink  = shortlink,
                 linkpassword = linkpassword 
            )
    
    respcnt <- pcloud.lapi("getfilepublink", pars)
    list(website = respcnt$link, linkid = respcnt$linkid, code = respcnt$code, cnt = respcnt)
}

#' @param  code      the sharing code returned by `pcloud.pub.down.filelink()`.
#' @param  endpoint  the sharing user endpoint, who can obtain it from [pcloud.endpoint()].
#' @param  rawoutput also show raw API output.
#' @return `pcloud.direct`: the URL to download the file, and a message with more link information if `rawoutput = TRUE`.
#' @name public-downloads
#' @export
pcloud.direct <- function( # Direct link for programmatic access
                          code,          # the sharing code returned by `pcloud.pub.down.filelink()`.
                          endpoint,      # the endpoint of the server where the file is.
                          rawoutput = FALSE # also show raw API output.
                          ) {

    ## Control edges
    host <- sub("*https?://", "", endpoint) |> sub("/$", "", x =_)
    url <- sprintf("https://%s/getpublinkdownload?code=%s", host, code)

    ## Get it
    rawjs <- readLines(url, warn = FALSE) |> paste(collapse = "\n")
    if(rawoutput) message(rawjs, "\n")

    ## Error? 
    rx <- regexpr("\"error\": +\"[^\"]+", rawjs)
    error <- regmatches(rawjs, rx)
    if(length(error)) {
        error <- strsplit(error, "\"")[[1]][4]
        stop(error)
    }
    
    ## Get path 
    rx <- regexpr("\"path\": +\"[^\"]+", rawjs)
    path <- regmatches(rawjs, rx)
    path <- strsplit(path, "\"")[[1]][4]
    path <- gsub("\\\\", "", path)
    
    ## Get first host
    rx <- regexpr("\"hosts\": +\\[[^]]+", rawjs)
    hosts <- regmatches(rawjs, rx)
    first.host <- strsplit(hosts, "\"")[[1]][[4]]

    ## Down URL
    paste0("https://", first.host, path)    
}
            
#' @param  text return the code as text.
#' @return `pcloud.read.link`: read data in raw format, or character if `text` is `TRUE`.
#' @name public-downloads
#' @export
pcloud.read.link <- function( # read data from public link 
                             code,          # the sharing code returned by `pcloud.pub.down.filelink()`.
                             endpoint,      # the endpoint of the server where the file is.
                             text = FALSE # return the code as text.
                             ) {

    dlink <- pcloud.direct(code, endpoint)
    resp <- curl::curl_fetch_memory(dlink)$content
    if(text) rawToChar(resp) else resp
}

#' @param local.path local path of the file to download.
#' @return `pcloud.down.from.plink`: the return value of `curl::curl_fetch_disk` invisibly.
#' @name public-downloads
#' @export
pcloud.down.from.plink <- function( # read data from public link 
                             code,          # the sharing code returned by `pcloud.pub.down.filelink()`.
                             endpoint,      # the endpoint of the server where the file is.
                             local.path     # local path of the file to download.
                             ) {

    dlink <- pcloud.direct(code, endpoint)
    invisible(curl::curl_fetch_disk(dlink, local.path))
}

#' @param linkid  the ID of the link to be deleted, returned by `pcloud.pub.down.filelink()`.
#' @return `pcloud.delink`: JSON response content invisibly.
#' @name public-downloads
#' @export
pcloud.delink <- function( # Delete public link
                          linkid            # the ID of the link to be deleted returned by `pcloud.pub.down.filelink()`.
                          ) {    
    respcnt <- pcloud.api("deletepublink", linkid = linkid)
    invisible(respcnt)
}


#' Public Upload Links
#'
#' Upload data, with `pcloud.pupload.data()`, and files, with `pcloud.pupload.file()`, to public links.
#' Get link information with `pcloud.pupload.info()`.
#'
#' pCloud allows to create a public link to a folder to request file.
#' The link is similar to an email, as a third party can only upload but can't see the content.
#'  
#' Unfortunately, the link creation is not supported through OAuth2, thus one has to use an alternative method.
#' For example, with the webapp, open the folder and select `Request files' under the ellipsis folder menu.
#'  
#' `pcloud.pupload.*` functions  share some similarities with `pcloud.write` and `pcloud.upload`,
#' but `pcloud.write` implies opening and closing file descriptors. 
#' Also, `pcloud.pupload.*` functions do not require authentication.
#'   
#' The philosophy of this package is to not ask the user their account credentials,
#' therefore we have no precooked function to create upload links. 
#' However, if you need programmatic creation of upload links and you are fine with password digest authentication, 
#' see the Examples section below to create an upload link to a folder using its `folderid`.
#' 
#' A convenient way to distribute sharing codes+endpoints could be to generate an encoded string including them.
#' See [pcloud.encodelink()]
#'
#' NOTE. For `pcloud.pupload.data()`, the `data` argument can  only be of type raw or character.
#' If it is `NULL`, zero-length, or an empty string, it is replaced with `raw(1)`,
#' which is equivalent a file with a single null-byte.
#' 
#' @examples
#' \dontrun{
#' ## Link creation without OAuth2 
#' username <- "***"; pass <-"***"
#' endpoint <- "***" # you can use pcloud.endpoint() to obtain it
#' folderid <- "***" # you can use pcloud.listfolder("/") to obtain it
#' comment <- "Upload files" # required
#'     
#' ## curl and digest packages required
#' curl <- function(url) rawToChar(curl::curl_fetch_memory(url)$content)
#' sha1 <- function(msg) digest::digest(msg, algo = "sha1", serialize = FALSE)
#'  
#' ## Create digest credentials
#' digest <- curl(sprintf("%s/getdigest", endpoint))
#' digest <- strsplit(digest, '"')[[1]][10]
#' passworddigest <- sha1(paste0(pass, sha1(tolower(username)), digest))
#' cred <- sprintf("logout=1&username=%s&digest=%s&passworddigest=%s",
#'                 username, digest, passworddigest)
#'  
#' ## Create upload link
#' curl(sprintf("%s/createuploadlink?%s&comment=%s&folderid=%s",
#'              endpoint, cred, curl::curl_escape(comment), folderid))
#'}

## createuploadlink method does not work with OAuth2 
# @param comment a comment to provide to uploading users.
# @return  `pcloud.createuploadlink`: a list with the elements which follow.
#          `uploadlinkid`: link can be used to modify/delete this link.
#           `link`: full link to a page where files can be uploaded.
#           `mail`: an email address that also can be used to upload files to this link.
#           `code`: link's code that can be used to upload files
# @name public-uploads
# @export
#pcloud.createuploadlink <- function( # Creates a link to a folder for public upload files and data 
#                                    remote.path = NULL, # the pCloud remote folder path, where the uploaded files will be saved
#                                    folderid    = NULL, # the pCloud folder ID.
#                                    comment             # comment the user is willing to provide to uploading users
#                                    ) { 
#    idorpath(remote.path, folderid)
#    pars <- list(
#        path      = remote.path,
#        folderid  = folderid, 
#        comment	  = comment
#    )
#    
#    respcnt <- pcloud.lapi("createuploadlink", pars)
#    list(uploadlinkid = respcnt$uploadlinkid, link = respcnt$link, mail = respcnt$mail, code = respcnt$code)
# 
#}

#' @param code      the value of the 'code' field in the public upload link.
#' @param endpoint  the endpoint of the destination user, who can obtain it from [pcloud.endpoint()].
#' @param data      data to write as character or raw.
#' @param username  name of the uploader.
#' @param filename  name of the destination file.
#' @param rawoutput also show raw API output.
#' @return `pcloud.pupload.data`: if `rawoutput=FALSE`, only the logical success;
#'         else prints JSON response content, success feedback, and invisibly return logical success.
#' @name public-uploads
#' @export
pcloud.pupload.data <- function( # Upload data to a public link as a file
                                code,            # the value of the 'code' field in the public upload link.
                                endpoint,        # the endpoint of the destination user, who can obtain it from [pcloud.endpoint()].
                                username,        # name of the uploader
                                data,            # data to write as character or raw                                
                                filename,        # name of the destination file.
                                rawoutput = FALSE # also show raw API output.
                                ) {

    ## In case code is copied on foreign system 
    # reqpaks <- c('curl')
    # mispkas <- reqpaks[! reqpaks %in% rownames(utils::installed.packages())]
    # if(length(mispkas)) stop("Missing pacakge(s) ", paste(mispkas, collapse = ", "))    
    # host <- sub("*https?://", "", endpoint) |> sub("/$", "", x =_)  # Control edges
    # code <- strsplit(uplink, "code=")[[1]][2]

    to.good.data(data)
    username <- paste0(username, gmttime())
    e <- \(txt) utils::URLencode(txt, reserved = TRUE)
    qry <- c(code = code, names = e(username), filescount = 1, filename = e(filename)) |>
        {\(x) paste(names(x), x, sep = "=", collapse = "&")} (x = _)    
    url <- sprintf("%s/uploadtolink?%s", endpoint, qry)

    local.handle <- curl::new_handle()  
    if(is.character(data)) data <- charToRaw(data)
    curl.opt <- list(post = TRUE,  postfieldsize = length(data), postfields = data, customrequest = "PUT")
    curl::handle_setopt(local.handle, .list = curl.opt)
    resp <- curl::curl_fetch_memory(url, local.handle)
    cnt <- rawToChar(resp$content)
    success <- grepl("\"result\": +0", cnt)
    if(rawoutput) {
        message(cnt)
        message(ifelse(success, "Data was uploaded", "Error uploading data"))
        return(invisible(success))
    } else success

}

#' @param local.path local path of the file to send.
#' @param curlwarn warn if the 'cURL' library does not support 'filename' args.
#' @return `pcloud.pupload.file`: if `rawoutput=FALSE` only the logical success;
#'          else prints JSON response content, success feedback, and invisibly return logical success.
#' @name public-uploads
#' @export
pcloud.pupload.file <- function( # Upload file to a public link
                                code,             # the value of the 'code' field in the public upload link.
                                endpoint,         # the endpoint of the destination user, who can obtain it from [pcloud.endpoint()].
                                username,         # name of the uploader.
                                local.path,       # local path of the file to send.
                                filename,         # filename to give to the uploaded file
                                curlwarn = TRUE,  # Warn if cURL does not support filename args.
                                rawoutput = FALSE # also show raw API output.
                                ) {

    ## In case code is copied on foreign system 
    # reqpaks <- c('curl')
    # mispkas <- reqpaks[! reqpaks %in% rownames(utils::installed.packages())]
    # if(length(mispkas)) stop("Missing pacakge(s) ", paste(mispkas, collapse = ", "))
    # ## Control edges
    # host <- sub("*https?://", "", endpoint) |> sub("/$", "", x =_)
    # code <- strsplit(uplink, "code=")[[1]][2]
    
    if(!is.null(filename) && utils::packageDate("curl") < "2023-02-15" && curlwarn)
        warning("Your curl package version does not support the 'filename' argument. Consider updating it.")

    username <- paste0(username, gmttime())
    e <- \(txt) utils::URLencode(txt, reserved = TRUE)
    qry <- c(code = code, names = e(username), filescount = 1) |>
        {\(x) paste(names(x), x, sep = "=", collapse = "&")} (x = _)    
    url <- sprintf("%s/uploadtolink?%s", endpoint, qry)

    local.handle <- curl::new_handle()
    curl.form <-
        if(utils::packageDate("curl") < "2023-02-15") 
            curl::form_file(local.path)
        else 
            curl::form_file(local.path, name = filename)
    curl::handle_setform(local.handle, files = curl.form)
    resp <- curl::curl_fetch_memory(url, local.handle)
    cnt <- rawToChar(resp$content)
    success <- grepl("\"result\": +0", cnt)
    if(rawoutput) {
        message(cnt)
        message(ifelse(success, "Data was uploaded", "Error uploading data"))
        return(invisible(success))
    } else success
}

gmttime <- function() { # get Google GMT time
    h <- curl::new_handle(NOBODY = TRUE)
    resp <- curl::curl_fetch_memory("http://www.google.com", h)
    head <- strsplit(rawToChar(resp$header) , "\n")[[1]]
    date <- grep("^Date: ", head)
    if(length(date) == 0) stop("Unable to get internet time.")
    time <- regexpr("\\d\\d:\\d\\d:\\d\\d", head[date], perl = TRUE) |> regmatches(head[date], m = _)
    paste0("_", time, "_GMT")
}


#' @return `pcloud.pupload.info`: a list with link info.
#' @name public-uploads
#' @export
pcloud.pupload.info <- function( # Info on a public link
                                code,           # the value of the 'code' field in the public upload link.
                                endpoint        # the endpoint of the destination user, who can obtain it from [pcloud.endpoint()].
                                ) {
    url <- paste0(endpoint, "/showuploadlink?code=", code)
    resp <- curl::curl_fetch_memory(url)
    cnt <- rawToChar(resp$content)
    jsonlite::fromJSON(cnt)
}

#' Endpoint
#' 
#' `pcloud.endpoint()` returns the endpoint associated with the OAuth account.
#'
#' 
#' pCloud provides different data regions, where files and data are stored, which the user is able to select when signing on or later
#' for a fee. The endpoint denotes the server to which the API requests are sent and, for pCloud, it depends on the data region.
#'   
#' The endpoint is important for shared resources, in fact, to obtain direct links, which do not require to interactively access
#' pCloud website, it is is necessary both the sharing code and the endpoint.
#' 
#' @return endpoint string.
#' @name endpoint
#' @export
pcloud.endpoint <- function() # The account endpoint 
    pcloud.cred.get()$epoint


to.good.data <- function(data) { # test data is raw or char and if empty convert to null-byte with a warning

    class <- paste(class(data), collapse = ", ")

    if(is.null(data)) {
        data <- raw(1)
        warning("'NULL' data to send was replaced with 'raw(1)'")
    }

    else if(! inherits(data, c("raw", "character")))
        stop("You are trying to send to pCloud data of type ", class,
             ",\nbut you can only send raw or character data.")

    else if(length(data) == 0) {        
        data <- raw(1)
        warning("Zero-length data to send was replaced with 'raw(1)'")
    }
        
    else if(is.character(data) && !nzchar(data)) {        
        data <- raw(1)
        warning("Empty string to send was replaced with 'raw(1)'")
    }

    data
}


# LocalWords: sha
