pcloudrEnv <- new.env()
pcloudrEnv$handle <- NULL             # curl handle
pcloudrEnv$accodes  <- NULL           # secretr with serialised list of pCloud access token and endpoint
pcloudrEnv$accodes.pt <- "~/pcloudr"  # accodes path 

#' Remote Paths
#'
#' When your app uses private folder access, the remote root path (`/`) is relative to the pCloud-assigned app folder.
#' If you use folder IDs, the root folder is always identified by `0`. 
#' 
#' When you register your app (see "Registering your app" in 'pcloudr' vignette or [pcloud.auth()]), you can to restrict
#' its access to an app specific folder. At the time of the registration, this setting is named _private folder access_, and
#' is later shown as 'Access' to 'Specific folder only' in the app settings available at
#' [https://docs.pcloud.com/my_apps/](https://docs.pcloud.com/my_apps/).
#'  
#' If compatible with your workflow, that is your app does not read access the entire drive,
#' this is a convenient security setting, which, by the way, affects the way you specify remote paths in pcloudr.
#'  
#' In general, you specify paths with the usual R (Unix) style, such as `/dir/subdir/hello.txt`,
#' where the first forward slash (`/`) denotes the root of your cloud drive, assuming your app has access to all folders. 
#' However, when you are using private folder access, your app operations are restricted to the cloud folder
#' `/Applications/<appname>`, where `appname` is the name you chose for your app.   
#' Given this, the file `/Applications/<appname>/hello.txt` is now seen by your app as `/hello.txt`,
#' put it another way, the root folder for the restricted app is `/Applications/<appname>/`.
#'  
#' Each file and folder have also a filesystem ID. As a rule, whenever you are required to give a path,
#' pcloudr functions allows you to give also the ID of the related filesystem object.
#' The ID is a unique number which is not affected by the private folder access setting. 
#'  
#' The IDs are provided by the [list-folder functions][pcloud.listfolder()].
#' Typically, these functions provide for each cloud item a `folderid`, `fileid`, and `id`.
#' The first two are integers, available only when the filesystem item is of the specified type, and `NA` otherwise,
#' e.g. the `folderid` of a file is `NA`. When pcloudr function arguments ask cloud IDs, you have to pass
#' `folderid` or `fileid` depending on the type of item required. For your convenience, an `id` field is also provided,
#' which gives a unified view, where the IDs of folders are prefixed with a 'd'.
#'
#' There is a special ID, `0`,  which always identifies the root folder,
#' and therefore it is affected by restrictions to a private folder.
#' @name remote-paths
NULL

#' Authorise a registered app
#'
#' Interactive procedure to authorise a client app registered on pCloud.
#'
#' It is suggested that you have a look at the 'pcloudr' vignette before using this function.
#' Start it with `browseVignettes("pcloudr")`.
#' 
#' A pCloud app can be registered at [https://docs.pcloud.com/my_apps/](https://docs.pcloud.com/my_apps/),
#' possibly setting 'Folder access' to 'Private' (and later shown as 'Access' to 'Specific folder only').
#' 
#' The `client.id` and `client.secret` are visible in the app page, and
#' in the app 'Settings' one or more redirect URIs should be set in the form `http://localhost:xxxx`,
#' where `xxxx` is the desired TCP port number to be used in the `ports` vector.
#' For example: `http://localhost:65432` and `http://localhost:65433`.
#' Also, for better security, disallow the `implicit grant' setting.
#'
#' If `no.file = TRUE`, at the end of the session the authorisation is lost and you have to repeat the procedure, also
#' `prompt`, `policy`, and `mask` args are ignored without errors.
#' 
#' If `no.file = FALSE`, the default, pCloud access codes (access token and endpoint) are saved encrypted to `~/pcloudr`, 
#' but you can set an alternative path with [pcloud.config()].
#' In this case, you are prompted (with a graphical interface) to provide an encryption password.
#' The prompt describes the password security policy, which you can also obtain from `secretR::pwpolicy()$pwdesc`.
#' You might also set your own policy with `secretR::pwpolicy()` and supply it to the function's `policy` argument.
#' 
#' @seealso `[secretR::pwpolicy()]`, [pcloud.config()], `browseVignettes("pcloudr")`
#' 
#' @param client.id the app client identification issued at registration.
#' @param client.secret the app client secret issued at registration.
#' @param ports a numeric vector of the redirect ports set during the app registration.
#'        A port is the `xxxx` component in the `http://localhost:xxxx` redirect URIs.
#' @param prompt if non-null, it the the user prompt asking the password to encrypt pCloud access codes.
#' @param policy the security policy used to set the encryption password for pCloud access codes.
#'        Use `secretR::pwpolicy()$pwdesc` to print the current policy and `?secretR::pwpolicy` to learn how to change it.
#' @param mask masking the characters from prying eyes when inputting the password?
#' @param no.file If `TRUE`, save pCloud access codes to `~/pcloudr` or the values set with `pcloud.config()`.
#' @return logical value for success.
#' @name authorising
#' @export
pcloud.auth <- function(client.id, client.secret, ports,  # the function return FALSE or TRUE on success 
                        prompt = NULL,   # if non-NULL, the prompt to save access token
                        policy = secretR::pwpolicy(),  # the password policy used when saving the prompt
                        mask = TRUE,
                        no.file = FALSE  # save access token to file?
                        ) {

    ereq <- auth.env()
    server <- startListening(ports, ereq)
    if(is.null(server)) {
        noPort(ports)
        return(invisible(FALSE))
    }
    
    message("\nPlease, browse to the following pCloud address and authorise the app.")
    state <- sample(1:100000, 1)
    redir <- paste0("http://localhost:", server$getPort())
    qry <- querify(client_id = client.id, state = state, response_type = "code", redirect_uri=redir)
    message(paste0("https://my.pcloud.com/oauth2/authorize", qry, "\n"))
    message("Waiting for authentication by pCloud.com... (Press Ctrl+C to force exit)")

    on.exit(httpuv::stopServer(server))
    while (is.null(ereq$resp)) {
        httpuv::service()
        Sys.sleep(0.001)
    }
    server$stop()
    ## print(sapply(names(ereq$resp), function(name) ereq$resp[[name]])) # debug reuest

    ## Check random state value
    qry <- unquerify(ereq$querystring)
    if(state != as.numeric(qry["state"])) {
        if(yesno("A random state value was not retuned as expected. It seems better to stop and repeat the operation."))
            stop("Stopped by user.")
    }
        

    ## Extract temprorary token and endpoint
    endpoint <- paste0("https://", qry["hostname"])
    tmptok <- qry["code"]

    ## Ask for non temporary access token
    method <- "oauth2_token"
    qry <- querify(client_id = client.id, client_secret = client.secret, code = tmptok)
    resp <- fetch(endpoint, method, qry, json = TRUE, slow = TRUE)

    ## Did pCloud send us the access token?
    accesstok <- resp$cnt$access_token
    error <-  if(is.null(accesstok)) TRUE else FALSE

    if(!error) {
        ## Serialise token+endpoint to pcloudr environment
        tokenend <- list(acctok = accesstok, endpoint = endpoint)
        tokenend.raw <- serialize(tokenend, connection = NULL)
        pcloudrEnv$accodes <- secretR::passcode(tokenend.raw)

        ## Test token 
        ret <- pcloud.api("userinfo")
        error <- is.null(ret)
    }

    if(error) {      
        message("Something went wrong. Try to repeat the operation",
                ifelse(is.null(resp$cnt$error), "", paste(". Server says:\n", resp$cnt$error)))
        return(invisible(FALSE))
    }
    message("Authorisation successful!")
    
    ## Store token to disk  with endpoint
    if(no.file)  return(invisible(TRUE))
    message("Saving the the access codes to local filesystem...")
    pass.txt <- FALSE      # plain pass as a string
    pass.secretr <- FALSE  # plain pass as a secretr

    ## Encrypt file via environment variables 
    pass.txt <- Sys.getenv("PCLOUDRKEY", unset = NA)
    if(!is.na(pass.txt)) {
        message("Using PCLOUDRKEY environment variable to set password.")
        compliant <- secretR::pwpolicy.check(pass.txt, policy = policy)
        if(compliant) pass.secretr <- secretR::passcode(pass.txt)
        else message("PCLOUDRKEY variable values is non-compliant, using dialogue.")
    }

    ## GUI encryption
    if(isFALSE(pass.secretr)) {
        prompt <- "Enter a password to save pCloud access codes:"
        pass.secretr <- secretR::pwset(prompt = prompt, policy = policy)
    }

    ## Encrypt
    tokenend.enc <- secretR::cipher(secretR::secretr.open(pcloudrEnv$accodes), pass.secretr)
    secretR::writeSecret(tokenend.enc, pcloudrEnv$accodes.pt)
    return(invisible(TRUE))
}

#' Package configuration 
#' 
#' Set package options. Currently the only option is the custom path to pCloud access codes, an encrypted file.
#' The option is stored in memory, thus it needs to be re-set on each session.
#' 
#' @param accodes.path the path to the encrypted file containing the pCloud access codes.
#' @export
pcloud.config <- function(accodes.path) { ## Set customised access codes path. If used, you have to recall it in each session

    if(!dir.exists(dirname(accodes.path))) warning("The path you provided does not seem valid")
    pcloudrEnv$accodes.pt <- accodes.path 
}

pcloud.cred.read <- function( ## Decrypt & read credentials from pcloudrEnv$accodes.pt
                         mask = TRUE  # mask input
                         ) { 

    ## Get fila path
    file <- pcloudrEnv$accodes.pt
    if(!file.exists(file)) {
        stop("I am unable to find the pcloud.cred.read file.\n", 
             "Repeat authorisation of this device or use 'pcloud.config()'")
    }
    
    ## read and decrypt encrypt cyper file
    tokenend.enc <- secretR::readSecret(file) # token encrypted
    tokenend.raw <- FALSE  # token decrypted
    pass.txt <- FALSE      # plain pass as a string
    pass.secretr <- FALSE  # plain pass as a secretr

    ## Decrypt file via environment variables 
    pass.txt <- Sys.getenv("PCLOUDRKEY", unset = NA)
    if(!is.na(pass.txt)) {
        message("Using PCLOUDRKEY environment variable to set password.")
        pass.secretr <- secretR::passcode(pass.txt)
        tokenend.raw <- secretR::secretr.open(tokenend.enc, pass = pass.secretr)
        if(isFALSE(tokenend.raw)) message("PCLOUDRKEY variable failed, using dialogue.")
    }
        
    ## GUI decryption
    if(isFALSE(tokenend.raw)) repeat {
        pass.secretr <- secretR::pwget(prompt = "Enter the password used to encrypt pCloud access codes:", mask = mask)
        tokenend.raw <- secretR::secretr.open(tokenend.enc, pass = pass.secretr)
        if(!isFALSE(tokenend.raw)) break
        yes <- yesno("Do you want to retry?")
        if(!yes) stop("Stopped by user") 
    }
    
    ## Store in memory as a secretr
    pcloudrEnv$accodes <- secretR::passcode(tokenend.raw)

}


pcloud.cred.get <- function( ## Get credentials, possible reading storage
                         mask = TRUE  # mask input
                         ) {

    if(is.null(pcloudrEnv$accodes)) pcloud.cred.read(mask = mask)
    
    ## Unserialise token+endpoint
    tokenend <- unserialize(secretR::secretr.open(pcloudrEnv$accodes))
    endpoint <- tokenend$endpoint
    acctok <- tokenend$acctok

    list(token = acctok, epoint = endpoint)


}

pcloud.sethandle <- function() { # Set keep-alive. Don't return handle or lose environment referencing

    if(is.null(pcloudrEnv$handle)) {
        pcloudrEnv$handle <- curl::new_handle()
        pars <- list(pcloudrEnv$handle, 
                     "Connection" = "keep-alive", # required for current pCloud HTTP 1.1
                     "Keep-Alive" = "timeout=5, max=1000")
        do.call(curl::handle_setheaders, pars)
 
        
#        curl::handle_setheaders(pcloudrEnv$handle,
#                                "Connection" = "keep-alive", # required for current pCloud HTTP 1.1
#                                "Keep-Alive" = "timeout=5, max=1000")
    }  
}


#' Generic API call
#'
#' Call  any method documented at [https://docs.pcloud.com/methods/](https://docs.pcloud.com/methods/).
#'
#' These functions allow to call any pCloud API method (unless it does not support OAuth2).
#' Use them if you want to use documented methods as-is, but get rid of the intricacies of OAuth2.
#' 
#' `pcloud.api()` is a more streamlined version of `pcloud.lapi()` with less features.   
#' The convenience of `pcloud.api()` is that you don't have to wrap methods arguments inside a list.
#' However, bear in mind that, should a method have the same arguments as `pcloud.api()`, for example `mask`,
#' then the function would "steal" from the method, taking precedence, thus you have to switch to `pcloud.lapi()`
#' to pass the argument.
#'
#' If the response content-type is JSON, the value is converted to a named list with `jsonlite::fromJSON()`.
#'  
#' @param method    the API method to call
#' @param pars      named list of method parameters.
#' @param ...,      named R arguments converted into method parameters.
#' @param mask      masking the characters from prying eyes
#'                  when inputting the password to read pCloud access codes from disk.
#' @param slow      add some connection tests before requests.
#' @param logical   return logical success.
#' @param rawoutput verbose output as from the [style guide][formats].
#' @return The requests response possibly jsonified.
#' @name pcloud-api
#' @export
pcloud.api <- function( # return a generic API-method response or NULL in case of error
                       method,            # the API method
                       ...,               # named R arguments converted into method parameters
                       mask = TRUE,       # masking the characters from prying eyes when inputting the password?
                       logical = TRUE,    # return logical success
                       rawoutput = FALSE  # verbose error output. See [Formats and Style][formats].
                       ) {
    dots <- list(...)
    do.call(pcloud.lapi, c(method = method, pars = list(dots),
                           mask = mask, logical = logical, rawoutput = rawoutput))
}

#' @param  curl.opt  option list for curl::handle_setopt
#' @param  curl.form option list for curl::handle_setform
#' @param nosimplejson do not apply simplification to JSON output.
#' @name pcloud-api
#' @export
pcloud.lapi <- function( # return a generic API-method response or NULL in case of error
                       method,              # the API method
                       pars,                # named list of method parameters
                       mask = TRUE,         # masking the characters from prying eyes when inputting the password?
                       slow = FALSE,        # add connection tests before request
                       curl.opt = NULL,     # option list for curl::handle_setopt
                       curl.form = NULL,    # option list for curl::handle_setform
                       logical = TRUE,      # return logical success
                       nosimplejson = FALSE,# do not apply simplification to JSON output.
                       rawoutput = FALSE    # verbose error output. See [Formats and Style][formats].
                       ) { 
    ## Set query
    cr <- pcloud.cred.get(mask) 
    qry <- do.call(querify, c(access_token = cr$token, pars)) 

    ## Set handles
    pcloud.sethandle() # No handle return to keep environment referencing!
    if(!is.null(curl.opt))  {
        curl::handle_setopt(pcloudrEnv$handle, .list = curl.opt)
        on.exit(pcloudrEnv$handle <- NULL) # custom opts maybe disruptive
    }          
    if(!is.null(curl.form))  {
        curl::handle_setform(pcloudrEnv$handle, .list = curl.form)
        on.exit(pcloudrEnv$handle <- NULL) # perhaps less disruptive
    }

    ## Ask request
    resp <- fetch(cr$epoint, method, qry, json = FALSE, handle = pcloudrEnv$handle, slow = slow)
    pcloud.resp_(resp, method, pars, "response") 
    
    ## Some methods have variable type so we have to check
    is.json <- resp$type == "application/json"
    if(is.json) resp$cnt <- fromJSON.fix(resp$cnt, nosimplejson)
    pcloud.resp_(resp, method, pars, "content") 

    ## pCloud API-managed errors return resp$cnt$error
    if(is.json && !is.null(resp$cnt$error)) { #implies resp$cnt$result > 0
        stop(resp$cnt$error)
    } else if(!resp$ok) {
        stop(paste("The request reaturned status", resp$code))
    } else {
        invisible(resp$cnt)
    }
}

#' Debugging server responses
#'
#' While internally pcloudr functions retrieve the server response, this is usually not shown to the user.
#' By wrapping the call inside `pcloud.resp(...)`, it is possible to obtain the original server response.
#'
#' For more information regarding internal pcloudr format see [Formats and Style][formats].
#' 
#' @param expr  the function call for which the server response is required
#' @param cont  if TRUE, return only the jsonified element of the full response list  (see [Formats and Style][formats].)
#' @param multi when multiple server requests occur, return only the last one (FALSE) or all of them (TRUE).
#' @return If `multi = TRUE` a list with all the responses given to each request.
#'         Responses consist of the jsonified server response if `cont = TRUE` or only its `cnt` element if `FALSE`.
#'         Responses have also a query element with the relevant part of the URL requested.
#' @export
pcloud.resp <- function( # return a generic API-method response or NULL in case of error
                        expr,
                        cont  = FALSE,
                        multi = FALSE
                        ) {

    pcloudrEnv$resp <- NULL
    if(cont) pcloudrEnv$getcont <- TRUE else pcloudrEnv$getresp <- TRUE
    if(multi) pcloudrEnv$getmulti <- TRUE
    on.exit({
        pcloudrEnv$getresp <- NULL
        pcloudrEnv$getcont <- NULL
        pcloudrEnv$getmulti <- NULL
        pcloudrEnv$resp <- NULL
    })
    try(expr)
    message("\nRetrieving server response...\n")
    if(is.null(pcloudrEnv$resp))
        message("Sorry, no response was received.") else pcloudrEnv$resp
}

pcloud.resp_ <- function( # Depending on global pcloudrEnv$getresp/getcont, save full/json content of response to pcloudrEnv 
                         cresp,  # full response
                         method, # request method 
                         pars ,  # request relevant pars (no token)
                         ready   # what is now ready for possible saving?
                         ) {
### We call this function whenever certain outputs are available,  and the function decides if and what saving

    save <- switch(ready,
                   response = if(!is.null(pcloudrEnv$getresp)) cresp,
                   content  = if(!is.null(pcloudrEnv$getcont)) cresp$cnt
                   )
    
    if(!is.null(save)) {
        pars <- do.call(querify, c(method, pars)) 
        qsave <- c(pars, save)
        pcloudrEnv$resp <- if(is.null(pcloudrEnv$getmulti)) qsave else c(pcloudrEnv$resp, list(qsave))
    }
}

#' Managing exceptions
#' 
#' If the expression `expr` throws an exception, `pcloud.try(expr)` prints its stop message and continue returning FALSE.
#' This is useful when in loops and conditionals, to take action upon failure such as repeating the command a n times.
#'
#' @param expr expression potentially throwing an exception.
#' @export
pcloud.try <- function(expr) { # if an expression throws an exception, print stop message and continue returning FALSE
    tryCatch(expr, error = function(e) {
        message(e$message)
        FALSE
    })
}

startListening <- function(ports, ereq) { # Open first available port and return listening server

    for (port in ports) {
        s <- NULL
        tryCatch(
            s <- httpuv::startServer("127.0.0.1", port, ereq, quiet = TRUE),
            error = function(e) { }
        )
        if (!is.null(s)) break    
    }
    s
}

auth.env <- function() { # setup the auth environment, including listening callback
    ereq <- new.env()
    ereq$resp <- NULL
    ereq$querystring <- NULL
    ereq$call <- function(req) {
        body = paste('<h2>Thank you. You can close this tab.</h2>')
        assign("resp", req, envir = environment(sys.function())) 
        query <- req$QUERY_STRING
        if(!is.null(query) && nzchar(query)) # this should avoid to catch /favinco.ico
           assign("querystring", req$QUERY_STRING, envir = environment(sys.function()))
        list(
            status = 200L,
            headers = list('Content-Type' = 'text/html'),
            body = body)
    }
    environment(ereq$call) <-  ereq
    ereq
}



# LocalWords:  pCloud
