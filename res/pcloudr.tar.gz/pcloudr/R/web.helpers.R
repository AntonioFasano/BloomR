querify <- function(...) { # build URL query component from  a "name = value ..." sequence, removing NULLs
### ?-prefix added
    
    L <- list(...)
    L <- L[!sapply(L, is.null)] # remove nulls
    flds <- sapply(names(L), curl::curl_escape)
    vals <- sapply(L, curl::curl_escape)
    q <- paste(flds, vals, sep="=", collapse = "&")
    paste0("?", q)
}


unquerify <- function(qry) { # the reverse of querify, returning a named char vector

    qry <- sub("^\\?", "", qry)
    strsplit(qry, "&")[[1]] |> strsplit("=") |> sapply(\(fld) stats::setNames(fld[2], fld[1])) 
}


fetch <- function( # Fetch endpoint/method?query. Perhaps recycling the handle and jsonifying   
                  endpoint, # flexible trailing '/'
                  method = NULL,
                  query = NULL,  # par1=value1&... properly encoded 
                  handle = curl::new_handle(),
                  json = FALSE,  # if T, jsonify the response
                  slow = FALSE # if T, make connection tests
                  ) {
### Extra /s or ?s are removed. Query is can be built with querify()

    ## Connection test
    if(slow) {
        if(!curl::has_internet()) stop("You seem to not have an internet connection right now!")
        hostname <- strsplit(sub("https?://", "", endpoint), "/")[[1]][1]
        for(i in 1:3) {
            if(i>1) message("Connection problems. Trying again...")
            if(!is.null(res <- curl::nslookup(hostname, error = FALSE))) break
        }    
        if(is.null(res)) stop("Unable to resolve: ", hostname)
    }
    
    url <- paste0(sub("/$", "", endpoint), "/", method, query)
    for(i in 1:3) {
        if(i>1) message("Connection problems. Trying again...")
        req <- curl::curl_fetch_memory(url, handle = handle)
        if(OK <- req$status_code < 400) break
    }
    type <- curl::parse_headers_list(req$headers)$`content-type`
    type <- strsplit(type, ";")[[1]][1]
    cont <- if(type == "application/octet-stream") req$content else rawToChar(req$content)
    cont <- if(json) fromJSON.fix(cont) else cont
    list(ok = OK, cnt = cont, code = req$status_code, type = type)
    
}

fromJSON.fix <- function( # convert hash to string before jsonlite::fromJSON
                         jsonstr,
                         nosimplejson # do not apply simplification to JSON output.
                         ) {  
### R might have problem to represent huge numbers

    ## "hash": 1234, -> "hash": "1234",
    jsonstr.fix <- gsub("(\"hash\": )([[:digit:]]+),",
                        "\\1\"\\2\",", jsonstr)  

    jsonlite::fromJSON(jsonstr.fix,
                       simplifyVector = !nosimplejson, simplifyDataFrame = !nosimplejson, simplifyMatrix = !nosimplejson)
}
