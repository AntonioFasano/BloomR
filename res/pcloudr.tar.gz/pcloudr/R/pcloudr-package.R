#' Accessing pCloud from R with OAuth2
#' 
#' pcloudr lets you access to pCloud cloud programmatically from R through
#' OAuth2 delegated access.
#' 
#' To use pcloudr you first have to register an app in pCloud or anyway obtain app credentials.
#' Note that app credentials are not intended and cannot be secret for non-web apps. See the section
#' "Security considerations" in the vignette.
#' 
#' API functions try to catch JSON errors when they occur and stop, otherwise they return the intended result,
#' e.g. the content of a file or the success flag, "0" as character.
#'
#' If you want to get more information about the pCloud API methods wrapped by pcloudr, refer to
#' [https://docs.pcloud.com/methods/](https://docs.pcloud.com/methods/)
#'
#' Note that pcloudr functions are not a 1-to-1 mapping from pCloud API, but they try to adopt a higher-level approach,
#' possibly streamlining some cumbersome tasks. However, if you want to replicate an official method described
#' in the link above use [`pcloud.lapi()`] or the simplified version [`pcloud.api()`].
#' You just need to pass the method and the documented key-value fields, while delegating the
#' subtleties of OAuth2 authentication to pcloudr.
#' 
#' 
"_PACKAGE"
