#' Encoding Links `
#'
#' Generate encoded links for safer copy and paste.
#'
#' When you publish a public upload or download link, intended for subsequent copy-and-paste, the user might easily misselect it.
#' The encoding adds some redundant characters and a checksum to try to fix the selection or inform the user of the copy-error.
#'
#' The encoded link scheme is:
#'
#'     ===code@host@check===
#'
#' where 'code' is the code from `pcloud.pub.down.filelink()`;  'host' refers only to the second level API domain,
#'  assuming the domain name is always `*.pcloud.com`; check is a four-digit checksum;
#'  `=`'s are dummy redundant characters which reduce accidental misselection.
#' 
#' If you are publicly sharing a file with [`pcloud.pub.down.filelink()`],  `code` is one of the named components
#' returned by this function. The code is also contained as a parameter in the upload and download URLs,
#' intended for browser use. You can use `pcloud.url.code()` to extract the code value from a public link.
#' Because currently pCloud does not support creating upload links with OAuth2,
#' this comes handy to parse links obtained from alternative authentication methods or pCloud apps.
#' 
#' `pcloud.direct.dec()`, `pcloud.read.link.dec()`,  `pcloud.down.from.plink.dec()`, `pcloud.pupload.info.dec()`,
#' `pcloud.pupload.data.dec()`, and `pcloud.pupload.file.dec()`,
#' are equivalent to their counterpart without the `.dec` suffix, except
#' they replace the encoded string from `pcloud.encodelink()` for the sharing-code/endpoint pair.
#' 

#' @param code  the sharing code perhaps returned `pcloud.pub.down.filelink()`. See details.
#' @return `pcloud.encodelink`: the encoded link string.
#' @name encoding
#' @export
pcloud.encodelink <- function( # Encode the link for safer copy & paste
                              code     # the sharing code returned by `pcloud.pub.down.filelink()`.
                          ) {

    
    seclev <- sub("^https://", "", pcloud.endpoint()) |> sub("\\..+", "", x =_)
    sum <- sum(as.integer(charToRaw(paste0(code, seclev))))
    sum <- sprintf("%04d", sum)
    lnk <- paste(code, seclev, sum, sep = "@")
    paste("", lnk, "", sep = "===")
}

#' @param enclink the sharing code returned by `pcloud.pub.down.filelink()`.
#' @param error  if `FALSE` return NA on decoding error, rather than stopping.
#' @return `pcloud.decodelink`: a named list where 'code' is the sharing code returned by    
#'         `pcloud.pub.down.filelink()`
#'         and 'endpoint' the API endpoint of the sharing user.
#' @name encoding
#' @export
pcloud.decodelink <- function( # Deconde link from pcloud.encodelink()
                              enclink,       # the sharing code returned by `pcloud.pub.down.filelink()`.
                              error = TRUE   # if `FALSE` return NA on decoding error rather than stopping
                              ) {

    comps <- enclink |> gsub("=", "", x = _) |> strsplit("@") |> (`[[`)(1)
    code <- comps[1]
    seclev <- comps[2]
    check <- comps[3]
    sum <- sum(as.integer(charToRaw(paste0(code, seclev))))
    sum <- sprintf("%04d", sum)
    is.err <- is.na(check) || sum != check
    endpoint <- paste0("https://", seclev, ".pcloud.com")
    if(is.err && error) stop("Either you or the orginal poster mistyped the link.")
    if(is.err) NA
    else list(code = code, endpoint =  endpoint)     
}

#' @param url the URL from which we want to extract the code field.
#' @param autocode if `TRUE`, and `url` does not contain any of the chars in `/?=`, `url` is not parsed and considered a code as is.
#' @return `pcloud.url.code`: the extracted code string.
#' @name encoding
#' @export
pcloud.url.code <- function( # extract a the field 'code' from a generic url
                            url, autocode = FALSE
                            ) {
    if(autocode && !grepl("[/?=]", url)) return(url)
    if(!nzchar(url)) stop("You passed an empty string as URL")
    if(! grepl("&code=+.", url)) stop("No 'code' field found in URL\n", url)
    strsplit(url, "code=")[[1]][2]
}


#' @param  rawoutput also show raw API output.
#' @return `pcloud.direct.dec`: the URL to download the file, and a message with more link information if `rawoutput = TRUE`.
#' @name encoding
#' @export
pcloud.direct.dec <- function( # Like pcloud.direct(). but using the pcloud.encodelink() string
                              enclink,          # the encoded link string returned by pcloud.encodelink()
                              rawoutput = FALSE # also show raw API output.
                          ) {

    decoded <- pcloud.decodelink(enclink)
    pcloud.direct(decoded$code, decoded$endpoint, rawoutput)
}

#' @param  text return the code as text.
#' @return `pcloud.read.link.dec`: the read data in raw format, or character if `text` is `TRUE`.
#' @name encoding
#' @export
pcloud.read.link.dec <- function( # pcloud.read.link(), but using the pcloud.encodelink() string
                          enclink,          # the encoded link string returned by pcloud.encodelink()
                          text = FALSE # return the code as text.
                             ) {
    decoded <- pcloud.decodelink(enclink)
    pcloud.read.link(decoded$code, decoded$endpoint, text)
}
    
#' @param local.path local path of the file to download or upload (send).
## The send meaning is used by pcloud.pupload.file()
#' @return `pcloud.down.from.plink.dec`: the return value of `curl::curl_fetch_disk` invisibly.
#' @name encoding
#' @export
pcloud.down.from.plink.dec <- function( # pcloud.down.from.plink(), but using the pcloud.encodelink() string
                                 enclink,          # the encoded link string returned by pcloud.encodelink()
                                 local.path     # local path of the file to download.
                             ) {
    decoded <- pcloud.decodelink(enclink)
    pcloud.down.from.plink(decoded$code, decoded$endpoint, local.path)
}

#' @param data      data to write as character or raw.
#' @param username  name of the uploader.
#' @param filename  name of the destination file.
#' @return `pcloud.pupload.data.dec`: if `rawoutput=FALSE`, only the logical success;
#'         else prints JSON response content, success feedback, and invisibly return logical success.
#' @name encoding
#' @export
pcloud.pupload.data.dec <- function( # pcloud.pupload.data() but using the pcloud.encodelink() string
                                    enclink,          # the encoded link string returned by pcloud.encodelink()
                                    username,         # name of the uploader
                                    data,             # data to write as character or raw                                
                                    filename,         # name of the destination file.
                                    rawoutput = FALSE # also show raw API output.
                                    ) {

    decoded <- pcloud.decodelink(enclink)
    pcloud.pupload.data(decoded$code, decoded$endpoint, username = username, data = data, filename = filename,
                            rawoutput = rawoutput) 
}

#' @param curlwarn warn if the 'cURL' library does not support 'filename' args.
#' @return `pcloud.pupload.file`: if `rawoutput=FALSE` only the logical success;
#'          else prints JSON response content, success feedback, and invisibly return logical success.
#' @name encoding
#' @export
pcloud.pupload.file.dec <- function( # pcloud.pupload.file() but using the pcloud.encodelink() string
                                    enclink,          # the encoded link string returned by pcloud.encodelink()
                                    username,         # name of the uploader.
                                    local.path,       # local path of the file to send.
                                    filename,         # filename to give to the uploaded file
                                    curlwarn = TRUE,  # Warn if cURL does not support filename args.
                                    rawoutput = FALSE # also show raw API output.
                                    ) {

    decoded <- pcloud.decodelink(enclink)
    pcloud.pupload.file(decoded$code, decoded$endpoint, username = username, local.path = local.path, filename = filename,
                            curlwarn = curlwarn, rawoutput = rawoutput)
    
}

#' @return `pcloud.pupload.info.dec`: a list with link info.
#' @name encoding
#' @export
pcloud.pupload.info.dec <- function( # pcloud.pupload.file() but using the pcloud.encodelink() string
                                    enclink          # the encoded link string returned by pcloud.encodelink()
                                    ) {

    decoded <- pcloud.decodelink(enclink)
    pcloud.pupload.info(decoded$code, decoded$endpoint)
}
