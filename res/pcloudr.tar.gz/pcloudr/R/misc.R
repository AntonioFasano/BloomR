
#' Time Conversion
#'
#' Convert to and from pCloud time. These functions come handy when you want to make your own API calls with `pcloud.*api()`.
#' 
#' @param posix   R POSIXt time 
#' @return `pcloud.to.pctime`: a string similar to "2023-02-13T18:23:37+0100"
#' @name time
#' @export
pcloud.to.pctime <- function(posix # R POSIXt time 
                             ) {
    if(!inherits(posix, "POSIXt")) stop("'posix' argument should be a POSIXt class")
    format(posix, "%Y-%m-%dT%H:%M:%S%z")
}

#' @param pctime  pCloud time string, such as "Sun, 01 Jan 2023 14:50:44 +0000", to POSIXct
#' @return `pcloud.from.pctime`: a POSIXct time class.
#' @name time
#' @export
pcloud.from.pctime <- function(pctime # pCloud time string, such as "Sun, 01 Jan 2023 14:50:44 +0000" , to POSIXct
                               ) {   
    if(!is.character(pctime)) stop("'pctime' argument should be a character class")
    as.POSIXct(pctime, format = "%a, %d %b %Y %H:%M:%S %z")
}

idorpath <- function(remote.path, path.id) { # Test one arg is given for filesys object
    nulls <- sapply(c(remote.path, path.id), is.null)    
    if(length(nulls) == 0) stop("Remote path or ID is required")
    if(length(nulls) > 1) stop("Enter either a remote path or an id")
}


canbetext <- function(raw) { # Test if there are embedded nuls in a raw vector, preventing to convert it to a text.

#    raw <- as.raw(c(13, 255, 21, 3, 1, 100))
#    rtc <- rawToChar(raw, multiple = TRUE)    
    vals <- rle(raw)$values
    if(length(vals) < 3) return(TRUE)
    trvals <- vals[-c(1, length(vals))]
    !any(trvals == as.raw(0))
    
}

yesno <- function(msg) { # ask yes/no without the cancel annoyance
    repeat {
        msg <- paste(msg, "(y/n) ")    
        ans <- tolower(readline(msg))
        if(any(ans == c("y", "n"))) break
    }
    switch(ans, "y" = TRUE, "n" = FALSE)
}
