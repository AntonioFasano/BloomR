
<!-- README.md is generated from README.Rmd. Please edit that file -->

# pcloudr

<!-- badges: start -->
<!-- badges: end -->

pcloudr lets you access to pCloud cloud in R access through
[OAuth2](https://en.wikipedia.org/wiki/OAuth), which is an alternative
to username/password allowing better security and more granularity. See
the vignette for more information.

## Installation

You can install the development version of pcloudr like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(pcloudr)
## basic example code
```

post here?
<https://security.stackexchange.com/questions/176996/openid-connect-oauth-2-0-and-fake-official-apps>
<https://stackoverflow.com/questions/37931276/what-is-preventing-fake-apps-from-hijacking-a-legitimate-apps-oauth2-clientid>
<https://stackoverflow.com/questions/50787847/how-to-store-oauth-client-id-on-native-apps>

# Misc

<https://docs.pcloud.com/my_apps/>

<!--  LocalWords:  pCloud OAuth2 OAuth
 -->
