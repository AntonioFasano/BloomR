SLEEP <- 1

### Common part
if(file.exists("~/pcloudr.dev")) {
    temp.image <- file("~/pcloudr.dev", "r")
    unlockBinding("pcloudrEnv",  asNamespace("pcloudr"))
    assign("pcloudrEnv",  unserialize(temp.image), asNamespace("pcloudr"))
    close(temp.image)
}

Sys.sleep(SLEEP)
message("\nConnection test")
x <- capture.output(pcloud.contest(), type = "message")
stopifnot(grepl(" items in root.", rev(x)[2]) && grepl(" secs elapsed.",  rev(x)[1]))

Sys.sleep(SLEEP)
message("Test testbed")
if(!(pcloud.exists.folder("/trashme")) || !pcloud.folder.empty("/trashme") || Sys.getenv("TRASHME.LINK") == "")
    stop("For testing you need an empty '/trashme' folder\n", "and the env var TRASHME.LINK with an upload-link to it")

## Create test functions
createst.dir <- function(path) {
    stopifnot(!pcloud.exists.path(path))
    pcloud.createfolderifnotexists(path)
    Sys.sleep(SLEEP)
    stopifnot(pcloud.exists.folder(path))
}
createst.file <- function(path) {
    stopifnot(!pcloud.exists.path(path))
    pcloud.write("1234567890", path)
    stopifnot(pcloud.exists.file(path))
}
deltest.dir <- function(path) {    
    stopifnot(pcloud.exists.folder(path))
    pcloud.delete.folderrec(path)
    stopifnot(!pcloud.exists.folder(path))
}
###end Common part

Sys.sleep(SLEEP)
message("Public download links")
createst.dir("/trashme/publinks")
pcloud.write("Hello all!", "/trashme/publinks/hello.txt")
plink <- pcloud.pub.down.filelink("/trashme/publinks/hello.txt")
message(plink$code) # Link down code 

Sys.sleep(SLEEP)
message("Test link")
x <- pcloud.read.link(plink$code, pcloud.endpoint(), text = TRUE)
stopifnot(identical(x, "Hello all!"))
x <- pcloud.down.from.plink(plink$code, pcloud.endpoint(), tempfile("pcloudr"))
stopifnot(identical(readLines(x$content, warn = FALSE), "Hello all!")) # x$content is the filename

Sys.sleep(SLEEP)
message("Test link manually")
dlink <- pcloud.direct(plink$code, pcloud.endpoint(), rawoutput = TRUE)
x <- rawToChar(curl::curl_fetch_memory(dlink)$content)
stopifnot(identical(x, "Hello all!"))

Sys.sleep(SLEEP)
message("Download-link encoding")
enc <- pcloud.encodelink(plink$code)
message(enc) # Encoded link to publish
stopifnot(plink$code == pcloud.decodelink(enc)$code)
stopifnot(pcloud.endpoint() == pcloud.decodelink(enc)$endpoint)

Sys.sleep(SLEEP)
message("Test encoded link:")
x <- pcloud.read.link.dec(enc, text = TRUE)
stopifnot(identical(x, "Hello all!"))
x <- pcloud.down.from.plink.dec(enc, tempfile("pcloudr"))
stopifnot(identical(readLines(x$content, warn = FALSE), "Hello all!")) # x$content is the filename

Sys.sleep(SLEEP)
message("Test encoded link manually")
## it suffices to check the direct links are the same 
dlink <- pcloud.direct.dec(enc)
x <- rawToChar(curl::curl_fetch_memory(dlink)$content)
stopifnot(identical(x, "Hello all!"))

message("Delete link")
pcloud.delink(plink$linkid) # delete link 

## Temp direct link lasts for a while
y <- curl::curl_fetch_memory(dlink)$content
stopifnot(identical(y, charToRaw("Hello all!")))

## but not the web page link
x <- curl::curl_fetch_memory (plink$cnt$link)$content
stopifnot(grepl('"error": +"This link is deleted by the owner', rawToChar(x)))

## Renaming does not remove the weblinkk
pcloud.renamefile("/trashme/publinks/hello.txt", topath = "/trashme/publinks/hello2.txt")
y <- curl::curl_fetch_memory(dlink)$content
stopifnot(identical(y, charToRaw("Hello all!")))
## or deleteing
pcloud.delete.file("/trashme/publinks/hello2.txt")
y <- curl::curl_fetch_memory(dlink)$content
stopifnot(identical(y, charToRaw("Hello all!")))
deltest.dir("/trashme/publinks") # we delete also the file folder, but to no avail
y <- curl::curl_fetch_memory(dlink)$content
stopifnot(identical(y, charToRaw("Hello all!")))
stopifnot(pcloud.folder.empty("/trashme")) # test we end block with consistency

Sys.sleep(SLEEP)
message("TRASHME.LINK public upload link")
uplink <- Sys.getenv("TRASHME.LINK")
code <- pcloud.url.code(uplink)
ep <- pcloud.endpoint()
x <- pcloud.pupload.info(code, ep)
stopifnot(x$result == 0)
 
Sys.sleep(SLEEP)
message("Upload data")
ml <- "mario@google.com"
suc <- pcloud.pupload.data(code, ep, ml, data = "hello world", filename= "myfile.txt", rawoutput = TRUE)
stopifnot(suc)
 
Sys.sleep(SLEEP)
message("Upload a file")
img <- file.path(R.home('doc'), "html/logo.jpg")
suc <- pcloud.pupload.file(code, ep, "mario@google.com", local.path = img, filename = "image.jpg",
                         curlwarn = FALSE, rawoutput = TRUE)
stopifnot(suc)

Sys.sleep(SLEEP)
message("Upload-link encoding")
enc <- pcloud.encodelink(pcloud.url.code(uplink))
message(enc) # Encoded link to publish
stopifnot(pcloud.url.code(uplink) == pcloud.decodelink(enc)$code)
stopifnot(pcloud.endpoint() == pcloud.decodelink(enc)$endpoint)
x <- pcloud.pupload.info.dec(enc)
stopifnot(x$result == 0)

message("Upload to encoded link")
suc <- pcloud.pupload.data.dec(enc, ml, data = "hello world", filename= "myfile.txt", rawoutput = TRUE)
stopifnot(suc)
 
Sys.sleep(SLEEP)
message("Upload a file")
img <- file.path(R.home('doc'), "html/logo.jpg")
suc <- pcloud.pupload.file.dec(enc, "mario@google.com", local.path = img, filename = "image.jpg",
                         curlwarn = FALSE, rawoutput = TRUE)
stopifnot(suc)

Sys.sleep(SLEEP)
x <- pcloud.narrow("/trashme")
stopifnot(all(grepl("mario@google.com", x$path)))
stopifnot(length(x$path) == 4)
x <- pcloud.listfolderfileids.rec("/trashme")
stopifnot(length(x) == 4)

## Clean
x <- pcloud.delete.foldercont("/trashme")
stopifnot(pcloud.folder.empty("/trashme"))


