stud.enrol <- new.env() # envir storing the student enrollment data in ~/classroom-exam-enrol.rds
stud.session <- new.env() # student non-persistent (non-serialised) data.
stud.attached.assign.name <- "elearnr.session" # student namespace for assignment variables

#' Enrolment
#'
#' `exam.enrol()` prompts for student data and classroom-exam code and
#' save it to the binary _student enrol file_ provided by [`.exam.enrol.file()`].
#'
#' You can at any time obtain your enrol with `exam.show.enrol()` and, if necessary,
#' the classroom-exam code can be later updated with `exam.update.code()`,
#' which is interactive if a code argument is not passed. 
#' 
#' @name enrol
#' @export
exam.enrol <- function() { # Get student data and classroom-exam code and save it to [`.exam.enrol.file()`]

    internet.test()
    
    ans <- ask("Do you have the classroom-exam code?")
    if(ans == 2  || ans == 0) {
        message("Ask the instructor and try again.")
        return(invisible())
    }
    
    message("Please, enter the data required below.\n")
    givenname <- trimws(readline("Enter your given name: "))
    familyname <- trimws(readline("Enter your family name: "))
    email <- trimws(readline("Enter your academic email: "))

    code <- ask.class.code()
    if(isNA(code)) return(invisible())
    email <- confirm.email(email)
    if(isNA(email)) return(invisible())
       
    studata <- list(givenname = givenname, familyname = familyname, email = email, exam.code = code)
    conf <- .exam.enrol.file()
    saveRDS(studata, conf)
    ret <- init.stud.enrol()
    message("Your data was saved to\n", conf)
    message("You can now continue with 'exam.download()'.")
    invisible(ret)
}


#' @param code the classroom-exam code to update.
#' @name enrol
#' @export 
exam.update.code <- function( # Update the classroom-exam code in the file and in memory
                             code = NULL # The classroom-exam code to update
                             ) { 

    check.stud.enrol()
    
    if(is.null(code))     
        code <- repeatedask("Enter the new classroom-exam code: ", "",
                            "enter it again?", "exit update?", ask.class.code.test)
    else ask.class.code.test(code)

    enfile <- .exam.enrol.file()
    sconf <- readRDS(enfile)
    sconf$exam.code <- code
    saveRDS(sconf, enfile)
    ret <- init.stud.enrol()
    message("Your data was saved to\n", enfile)
    invisible(ret)
}

#' @param nice.format `TRUE` for a nicely formatted output, or `FALSE` for scripting.
#' @name enrol
#' @export 
exam.show.enrol <- function( # Show Read the student enrol file 
                           nice.format = TRUE # nicely formatted data
                           ) { 

    check.stud.enrol()
    
    #conf <- stud.session$confdata
    conf <- as.list(stud.enrol)
    if(nice.format) {
        message(dQuote(conf$givenname), " ", dQuote(conf$familyname))
        message(dQuote(conf$email))
        message("Classrom-exam code:")
        message(conf$exam.code)
        invisible(conf)
    }
    else conf
}

init.stud.enrol <- function() { # Copy student ernol file data to session enviroment

    enfile <- .exam.enrol.file()
    if(!file.exists(enfile)) return(FALSE)
    conf <- readRDS(enfile)
    #stud.session$confdata <- conf
    list2env(conf, stud.enrol)    
    TRUE
}
                           

#' Exam Session
#' 
#' `exam.download()` download the exam data and #' `exam.send()`  send it in cloud.
#'
#' Each argument of `exam.send()` should be named:
#' the argument names are the variables to send and the argument values are the related values
#'
#' After sending, it si suggested to use `exam.clearmem()` to avoid name conflicts.
#' 
#' @name exam-session
#' @export
exam.download <- function() { # get exam using the stored classroom-exam code 

    check.stud.enrol()
    message("Downloading ...")
    internet.test()

    get.remote.boot()
    if(! can.send(activeonly = TRUE)) return(invisible(FALSE))
    get.assignment()
    get.download.time()
    ## Add course name to elearnr session .assignment
    a.set("course.name", stud.session$bootdata$course)
    message("Done! You can now type 'exam.info()'.")
}



#' @name exam-session
#' @export
exam.info <- function(){

    check.got.assign()
    i.assignment <- get(".assignment", stud.attached.assign.name)

    txt <- paste0("\n", i.assignment$text, "\n")

    ## Add mandatory vars
    nms <- names(i.assignment$classes)
    vals <- i.assignment$classes
    cls <- sapply(seq_along(nms), function(i)  paste0("class(", nms[i], ")\t==\t\"", vals[i], "\""  ) )
    cls <- paste(cls, collapse="\n")
    txt <- rbind(txt, "\nClasses:\n", cls, "\n")

    
    ## Add optional vars
    nms <- names(i.assignment$classes.opt)
    vals <- i.assignment$classes.opt
    cls <- sapply(seq_along(nms), function(i)  paste0("class(", nms[i], ")\t==\t\"", vals[i], "\""  ) )
    cls <- paste(cls, collapse="\n")
    txt <- rbind(txt, "\nOptional variables:\n", cls, "\n")


    ## Add optional vars
    txt <- rbind(txt, "\nSee also info.send()", "\n")
 
    message(txt)

    if(can.send()) message("You can still send.")
}

#' @examples
#' ## Send 'a' with its actual value and 'b' with value taken by ;foo'
#' \dontrun{
#' exam.send(a = a, b = foo)
#' }
#' @param ... names of the arguments are the names of the variables required to send, values are typically he same variables. 
#' @name exam-session
#' @export    
exam.send  <- function(...) {

    check.got.assign()
    internet.test()
    
    ## Single arg without name
    if(is.null(names(list(...)))) stop("Please, provide argument names.")

    ## more args and some without name
    x <- which(!nzchar(names(list(...))))
    if(any(x)) stop("\nArgument(s) in position ", as.character(x),  " missing name(s).")

    ## Some value are functions
    x <- sapply(seq_along(list(...)), function(i) if(is.function(list(...)[[i]])) TRUE else FALSE)
    # Show first of which giving the problem
    if(any(x)) stop("\nThe value of ", names(list(...))[[which(x)[1] ]], " is a function not a value.")

    ## Can I?
    if(! can.send()) return(invisible(FALSE))
    
    ## Make answer list
    A <- list(...)
    
    ## Make save list
    L <- list()
    L$values <- A
    L$.course.name <- a.get(".assignment$course.name")
    # L$.student <- stud.session$confdata
    L$.student <- as.list(stud.enrol)
    stud.session$times$sendat <- Sys.time()
    L$.times <-  stud.session$times
    ##L$.cmdhst <-  readLines(paste0("~/hst-", .assignment$course.name))

    ## Test send link
    linkerr <- pcloudr::pcloud.pupload.info.dec(stud.session$bootdata$stud.upload.ecode)$result != 0
    if(linkerr) stop("Sorry, the there a issue with the upload link. \nPlease, report this to instructor.", call. = TRUE)

    ## Send data
    databin <- binCompress(L)
    #remotename <- strsplit(stud.session$confdata$email, "@")[[1]][1]
    remotename <- strsplit(stud.enrol$email, "@")[[1]][1]   
    message("Sending data...")
    pcloudr::pcloud.pupload.data.dec(enclink =  stud.session$bootdata$stud.upload.ecode,
                                     #username =  stud.session$confdata$email,
                                     username =  stud.enrol$email, 
                                     databin, filename = remotename)
    message("Data have been sent. Thank you.")
    message("It suggested that you run  'exam.clearmem()'.")
    return(invisible(TRUE))
}

#' @name exam-session
#' @export    
exam.clearmem  <- function() { # clear memory detach the elearnr session from the search path
    while(stud.attached.assign.name %in% search()) detach(stud.attached.assign.name, character.only = TRUE)    
}

ask.class.code <- function() { # prompt for classroom-exam code
    repeatedask("Enter your classroom-exam code: ", "", "enter it again?", "exit enroll?", ask.class.code.test) 
}

ask.class.code.test <- function( # test classroom-exam code during enrolment
                                enclink,
                                interactive = TRUE # with F stop when it would just message
                                ) {
    
    error <- isNA(pcloudr::pcloud.decodelink(enclink, error = FALSE))
    if(error) {
        msg <- "The code you entered is incorrect"
        if(interactive == TRUE) message(msg, ". Do you want to") else stop(msg)
        return(FALSE)
    }
    
    test <- more.student.code.tests(enclink)
    if(isTRUE(test)) return(TRUE)

    if(test != "deleted")
        stop(paste0("Despite passing the checksum, the classroom-exam code\n", enclink, 
                    " is invalid.\nPlease, report this error to the instructor to learn how to proceed further"),
             call. = FALSE)

    msg <- "The classroom-exam code is expired"
    if(interactive == TRUE) message(msg, ". Do you want to") else stop(msg)
    return(FALSE)
    
}

confirm.email <- function(email) { # Confirm previously entered email 

    message("\nCan you kindly confirm that this is your academic email?")
    ans <- ask(email,
               c("Yes.", "No! Let me reenter it again.", "I want to exit enroll without saving."))

    if(ans == 0 || ans == 3) return(NA) # exit
    if(ans == 2) { # reenter
        email <- trimws(readline("Enter your academic email: "))
        ans <- ask(paste("Confirm", email, "?"), c("Yes.", "No"))
        if(ans != 1) {
            message("Perhaps take a break and then try again.")
            return(NA) # exit
        }
    }
    tolower(email)
}

check.stud.enrol <- function() { # raise an error if the the enrol file is missing
    errmsg <- paste(
        "There is no enrol data: either you did not enrol or you deleted the enrol file.",
        "\nTo enrol (again) use the function: 'exam.enrol()'")
    if(!file.exists(.exam.enrol.file())) stop(errmsg, call. = FALSE)
    
    ## We should never get here since function who touch the enrol file should also sync stud.enrol
    if(length(ls(stud.enrol)) == 0) init.stud.enrol()
}


get.remote.boot <- function() { # get remote boot data, using the stored classroom-exam code

    #exam.code <- stud.session$confdata$exam.code
    exam.code <- stud.enrol$exam.code
    test <- more.student.code.tests(exam.code)
    if(!isTRUE(test)) {
        msg <- if(test == "deleted") "The classroom-exam code is expired."
               else "Despite passing the checksum, the classroom-exam code is invalid."

        msg <- paste(msg,
                     "\nThe code provided during the enrol was:", exam.code,
                     "\nYou can update it with a fresh one using exam.update.code()")
        stop(msg, call. = FALSE)        
    }

    boottext <- pcloudr::pcloud.read.link.dec(exam.code, text = TRUE)
    bootdata <- parse.boot.data(boottext)
    stud.session$bootdata <- bootdata
}

more.student.code.tests <- function(enclink) { # test for code errors other than checksum

    decoded <- pcloudr::pcloud.decodelink(enclink)
    ret <- tryCatch(pcloudr::pcloud.direct(decoded$code, decoded$endpoint), error = \(e) e)
    if(!inherits(ret, "error")) return(TRUE)
    ## is the classroom-exam code expired (i.e. deleted by the instructor)?
    if(grepl("deleted", ret$message)) "deleted" else "invalid"
    ## Invalid code is an edge case, for a code automatically generated        
}

parse.boot.data <- function(boottext) { # parse remote boot data 
    pairlines <- strsplit(boottext, "\n")[[1]] |> strsplit(split = ": ")
    names <- sapply(pairlines, `[[` , 1)
    values <- lapply(pairlines, `[` , -1) |> lapply(paste, collapse = "")
    setNames(values, names)
}

get.assignment <- function() {
    ass.rdata <- pcloudr::pcloud.read.link.dec(stud.session$bootdata$stud.assign.ecode)
    ass.rdata.unc <- binDecompress(ass.rdata)
    exam.clearmem()
    attach(ass.rdata.unc, name = stud.attached.assign.name)
}

get.download.time <- function() { # add the time download is completed    
        stud.session$times <-
        list(downloadat = Sys.time(), downloadat.txt = isotime(), downloadon.txt = isodate())
}

isotime <- function() {
    format(Sys.time(), usetz = TRUE) |> sub(" ", "T", x = _) |> sub(" ", "-", x = _) 
}

isodate <- function() {
    format(Sys.Date())
}


can.send <- function(# test if the send time has expired  or the cloud assignment build number is fresher than local
                     activeonly = FALSE  # do not check for build freshness 
                     ) { 

    bindata <- pcloudr::pcloud.read.link.dec(stud.session$bootdata$stud.expire.ecode)
    status <- binDecompress(bindata)
    active <- status$sendactive
    updtime <- format(Sys.time(), "%Y/%m/%d %H:%M")
    inact.msg <- paste("Sorry, sending results expired at", updtime)

    ## When about to donload frehness does not count
    if(activeonly) {
        if(!active) message(inact.msg)
        return(active)
    }
        
    ## If a student takes too much time their downloaded assignment may be overwritten by a new one 
    fresh <- status$exam.rnd.build == a.get("exam.rnd.build")
    if(!fresh && !active)
        message("Sorry, your assignment is not present on the server any more and there is no active one.")
    else if(!fresh && active)
        message("Your assignment is not present on the server any more, but there is a new active exam you can download.")
    else if(fresh && !active)
        message("Sorry, sending results expired at ",  strftime( status$updated))

    ## Can send if exam is fresh and active
    return(fresh && active)
}


internet.test <- function() {
    if(is.null(curl::nslookup("pcloud.com", error = FALSE, ipv4_only = TRUE)))
        stop("Hi there, I am afraid we have no internet connection")
}

#' Students' Dot Functions
#'
#' Dot functions are functions starting with a `.exam` prefix not intended for normal student usage,
#' but occasionally necessary for troubleshooting.
#'
#' _Student Enrol File_. `.exam.enrol.file()` returns the path of the student enrol file.
#' It is also used internally by functions reading and writing from and to it.
#'
#' _Test assignment freshness_. When a student takes too much time, their downloaded assignment may be
#' overwritten by a new one uploaded by the instructor. To detect conflicts, when created, assignments are associated
#' with a random build number distinguishing them, and functions, such as `exam.info` and `exam.send`, can use it
#' to determine if the assignment is current.
#' Beyond that, the instructor can ask a student to run `.exam.build()` to  compare the build of the student's
#' downloaded assignment with the build of the assignment stored in cloud, which, for the instructor,
#' is returned  by [`get.send.status()`].
#' 
#' @return `.exam.build`: the random exam build generated when the assignment was created.
#' @name student.dot
#' @export
.exam.build <- function() {
    
#    if(!is.assign()) {
#        message("There is no assignment downloaded.")
#        return(invisible())
#    }
    check.got.assign()
    a.get("exam.rnd.build")
}

#' @return `.exam.enrol.file()`: the student enrol file path.
#' @name student.dot
#' @export 
.exam.enrol.file <- function() { # Get the path to student enrol file 
    "~/classroom-exam-enrol.rds"
}


is.assign <- function() { # Test if an assignment was downloaded and attached to the search path 
    stud.attached.assign.name %in% search()
}

check.got.assign <- function() { # Raise an error if no file assignment was downloaded and attached to the search path 
        if(!is.assign()) 
            stop("There is no assignment downloaded. You can obtain the assignment with 'exam.download()'.",
                 call. = FALSE)

}


a.get <- function(elname) { # Get formally an element from the attached assignment env so as to pass compiler checks

    if(is.assign()) get(".assignment", stud.attached.assign.name)[[elname]] else NULL
}

a.set <- function(elname, value) { # Assign formally a value in the attached assignment env so as to pass compiler checks

    if(is.assign()) {
        a <- get(".assignment", stud.attached.assign.name)
        a[elname] <-  value
        assign(".assignment", a, stud.attached.assign.name)
    }
    else stop("No ", stud.attached.assign.name, " is currently attached.")
}

