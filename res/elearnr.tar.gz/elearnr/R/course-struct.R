#' Create the local and cloud folder structure 
#'
#' Set a local work directory and create the cloud folders `/<course>-download` and `/<course>-upload` folders, where
#' `<course>` is a prefix denoting a short name for the course. Recall, as noted in [remote-paths],
#' that to elearnr the cloud root is  by default relative to  `/Applications/elearnr`,
#' which is the only path where elearnr has access. The content of both cloud folders, can be deleted with `clear.structure()`,
#' or just the content of the upload folder if passing `both = FALSE`. 
#' This function does not require any confirmationm and automatically skips non-exiting folders,
#' therefore can be used in scripts before executing `setup.course()`.
#' 
#'  `/<course>-upload` is a public upload link ("Request for files") intended to receive student exercise submissions.
#' Submissions will be automatically dowloaded in a directory inside `course.locdir` named after current time
#' with the name format `yyyymmdd-HHMMSS`.
#' 
#' `/<course>-download` contains `stud.boot.txt`, with exam data intented for students, and the data files,
#' `<course>-wsol.rds` and `<course>-nosolRData`, with the solved and unsolved class exercise.
#'
#' The function saves configuration data to `~/elearnr.conf`,
#' unless an alternative value is given to `confile` argument.
#'
#' `/<course>-upload`, `/<course>-download`, and `course.locdir` are created if non-existant;
#' also the two cloud folders are deleted upon-confirmation if not empty.
#' Parameters defaultng to `NULL` can be inserted interactively. 
#' 
#' **Upload link**. For technical reasons, noted in `pcloudr::pcloud.pupload.data()` help, you are prompted to manually create
#' and input the public link to `/<course>-upload`.
#' To do this in the 'pCloud.com' webapp, create and open the folder `/<course>-upload`,
#' then select 'Request files' under the ellipsis folder menu and get link.
#' The upload link can be submitted interactively or passed through `uplink`.
#' Bear in mind that, when you delete and then recreate the folder `/<course>-upload`, the link has to be regenerated.
#'
#' **Classroom-Exam Code**. This is a nickname (perhaps too long) for a public link to `stud.boot.txt`,
#' returned by `setup.course()` and intended for distributions to students.
#' The link is necessary to bootstrap student-side functions,
#' e.g. it links to the `<course>-upload` folder and `<course>-nosolRData` data file.
#' If you want to distribute the classroom-exam code at a later tine, use  `give.exam.code()`,
#' and with `interactive = FALSE` to return it in a script.
#'
#' @param course a prefix without spaces representing a short course name.
#' @param course.locdir, path of local course directory.
#' @param uplink the upload link to `/<course>-upload` cloud folder as full URL or just the URL embedded code.
#'               This argument requires `course` too.
#' @param confile the package onfiguration file path. See [Configuration][read.conf()]
#' @param quiet  do not give informative messages.
#' @return `setup.course()`: While run primarily for its side effects, it also returns _classroom-exam code_, that is
#'                           the encoded public download link to `stud.boot.txt`, intended for distributions to students.
#' @name structure
#' @export
setup.course <- function(# Create `/<course>-download` and `/<course>-upload` folders.
                                course = NULL,  # A prefix without spaces representing a short course name.
                                course.locdir = NULL, # path of local course directory.
                                uplink = NULL,  # The upload link to `/<course>-upload` cloud folder. This requires `course` too.
                                confile = "~/elearnr.conf", # path to configuration file
                                quiet  = FALSE  # Do not give informative messages.
                                ) {

    verbose <- !quiet    
 
    ## Set course name and local course dir
    course <- get.course.name(course)
    course.locdir <- set.course.dir(course.locdir) 

    ## Create cloud files & folders
    downdir <- paste0("/", course, "-download")
    updir   <- paste0("/", course, "-upload")
    cloud.create.folder.safe(downdir)
    if(verbose) message("Created ", downdir)
    cloud.create.folder.safe(updir)
    if(verbose) message("Created ", updir)
    
    stud.boot.txt <- file.path.c(downdir, "stud.boot.txt")
    cloud.write.file.unsafe("", stud.boot.txt)
    if(verbose) message("Created ", stud.boot.txt)

    ## Dummy assignment no solutions
    data <- new.nosolRData()
    ## just similar hence no .RData dot
    nosolRData <- file.path.c(downdir, paste0(course, "-nosolRData"))
    cloud.write.file.unsafe(data, nosolRData)
    if(verbose) message("Created ", nosolRData)

    ## Dummy assignment with solutions
    data <- new.wsol.rds()
    wsol.rds <- file.path.c(downdir, paste0(course, "-wsol.rds"))
    cloud.write.file.unsafe(data, wsol.rds)
    if(verbose) message("Created ", wsol.rds)

    ## Expire file
    data <- binCompress(list(exam.rnd.build = NULL, sendactive = FALSE, updated = Sys.time()))
    expire.bin <- file.path.c(downdir, "expire.bin")
    cloud.write.file.unsafe(data, expire.bin)
    if(verbose) message("Created ", expire.bin)

    ## Get public uplink for receiving student files
    code <- get.uplink.code(uplink, updir)    
    stud.upload.ecode <- pcloudr::pcloud.encodelink(code)  
    if(verbose) message("Stored public upload link")

    ## Make public download links
    stud.assign.code <- pcloudr::pcloud.pub.down.filelink(nosolRData)$code
    stud.assign.ecode <- pcloudr::pcloud.encodelink(stud.assign.code)
    stud.expire.code <- pcloudr::pcloud.pub.down.filelink(expire.bin)$code
    stud.expire.ecode <- pcloudr::pcloud.encodelink(stud.expire.code)
    stud.boot.code <- pcloudr::pcloud.pub.down.filelink(stud.boot.txt)$code
    stud.boot.ecode <- pcloudr::pcloud.encodelink(stud.boot.code)  # to distribute
    if(verbose) message("Generated public download links")
    
    ## Add content to stud.boot.txt
    boottxt <- make.boot.config(
        course, stud.boot.ecode, stud.upload.ecode, stud.assign.ecode, stud.expire.ecode)
    cloud.write.file.unsafe(data = boottxt, stud.boot.txt)

    ## Save instructors' configuration
    write.conf(list(
        course            = "Short course name, used as a folder-prefix",
        course.locdir     = "Path of local course directory",
        stud.boot.ecode   = "\nPublink to student bootstrap file (to distribute)",
        stud.upload.ecode = "\nPublink to student upload folder", 
        stud.assign.ecode = "\nPublink to student RData-like assignment (no sol)",
        stud.expire.ecode = "\nPublink to student expiration flag file",
        nosolRData        = "\nCloud path to student RData-like assignment",
        expire.bin        = "\nCloud path to student expiration flag file",
        wsol.rds          = "\nCloud path to rds assignment with sols",
        updir             = "\nCloud path to student upload folder"        
    ), confile)
    read.conf() # store in elearnrEnv$config
    if(verbose) message("Saved configuration to ", confile)


    ## Return student bootstrap link 
    stud.boot.ecode
}

#' @param both if as per default `FALSE` delete only content of `/<course>-upload`, else `/<course>-download` too.
#' @return `clear.structure()`: While run primarily for its side effects, it also returns a list of removed objects
#'                             inside `/<course>-download` and `/<course>-upload`.
#' @name structure
#' @export
clear.structure <- function( # delete content of  `/<course>-download` and `/<course>-upload` folders
                            course,
                            both = FALSE # if F delete only  content of  `/<course>-upload`, else `/<course>-download` too.
                            ) { 
    downdir <- paste0("/", course, "-download")
    updir   <- paste0("/", course, "-upload")

    list(downdir = if(both && pcloudr::pcloud.exists.folder(downdir)) pcloudr::pcloud.delete.foldercont(downdir) else NULL,
         updir   = if(        pcloudr::pcloud.exists.folder(updir))   pcloudr::pcloud.delete.foldercont(updir)   else NULL)
}

#' @name structure
#' @export
#' @param interactive if TRUE, use a message to show the value. 
#' @return `give.exam.code()`: if `interactive = FALSE`, the classroom-exam code, else `NULL`.
#'                           In both cases, throw an error when a configuration is not available.
give.exam.code <- function(interactive = TRUE) {

    if(is.null(elearnrEnv$config$stud.boot.ecode))
        stop("Can't find the package configuration file. Did you setup the course with 'setup.course()'", call. = FALSE)

    if(interactive == TRUE) message("\n", elearnrEnv$config$stud.boot.ecode, "\n")
    else elearnrEnv$config$stud.boot.ecode

}


make.boot.config <- function(...) { # Create content for stud.boot.txt

    names <- as.character(substitute(list(...)))[-1L]
    values <- unlist(list(...))
    paste(names, values, sep = ": ", collapse = "\n")
    #kvs <- setNames(values, names)
    #lines <- sapply(kvs, function(kv) paste(names(kv), ": ", kv))
    #paste(lines, collapse = "\n")
                        
}

get.course.name <- function(course) {
    emsg <- "Please, do not use spaces in course name"
    nospc <- function(course) !grepl("[[:blank:]]", course)
    if(!is.null(course)) {
        if(!nospc(course))       stop(emsg, ": ", sQuote(course))
        else if(!nzchar(course)) stop("The course name you provided is empty")
    }
    
    if(is.null(course))
        course <- repeatedask("Enter a short course name (without spaces): ",
                              emsg, "Let me, renter the course name.", "I want to exit.", nospc)
    course
}

get.uplink.code <- function(# generate and input public upload link to `/<course>-upload`
                       uplink = NULL, # this can be the whole URL or just the code part
                       updir) { 
    ## if we have an uplink just check it
    if(!is.empty(uplink)) {
        uplink.test(uplink, updir, interactive = FALSE)
        return(pcloudr::pcloud.url.code(uplink, autocode = TRUE))
    }

    ans <- ask(paste("Please, create a public upload link to", updir),
               c("How can I create an upload link?", "I have created the upload link.", "I want to exit this procedure."))

    if(ans == 0 || ans == 3)  stop("Stopped by user", call. = FALSE)
    if(ans == 1) {
        message(paste("In 'pCloud.com' webapp, open the folder", updir,
                      "and select 'Request files' under the ellipsis folder menu.\n",
                      "Please, do not change the proposed sharing 'Message'"))
        get.uplink.code(uplink, updir) 
    } else {
        pcloudr::pcloud.url.code(
                     repeatedask("Enter the link to the whole upload URL \nor only the 'code' value: ",
                                 "\nDo you want to",
                                 "enter it again?", "exit enroll?",
                                 uplink.test, updir), autocode = TRUE
                 )
    }
}
    
uplink.test <- function( # test uplink code or expected comment (message) are correct
                        uplink, # this can be the whole URL or just the code part
                        updir, interactive = TRUE) { 
    code <- pcloudr::pcloud.url.code(uplink, autocode = TRUE)
    ep <- pcloudr::pcloud.endpoint()
    info <- pcloudr::pcloud.pupload.info(code, ep)
    error <- info$result != 0
    comment.due <- paste("File request for", sub("/", "", updir))
    comment.actual <- info$comment
    bad.comment <- comment.due != comment.actual
    rname <- paste0("elearn-", sample(1999:3999, 1))
    if(!bad.comment) {
        message("Attempting to upload the sample file ", rname,  " to ",  updir)
        pcloudr::pcloud.pupload.data(code, ep, username = rname, data = charToRaw(rname), filename = rname)
        dirs <- pcloudr::pcloud.listfolder(updir)
        found <- grep(rname, dirs$name)
        if(length(found) != 1) stop("Unable to find the uploaded file in ", updir, ". The provided uplink \n", uplink,
                                    "\nrefers to another folder, and the file went there (check it!).",
                                    call. = FALSE)
        pcloudr::pcloud.delete.folderrec(dirs[found])
        
    }
    
    errmsg <- 
        if(error) paste("Either the code is mistyped or it is not associated with the endpoint", ep)
        else if(bad.comment)
            paste("The expected comment (Message) for", updir, "is\n", comment.due,
                    "\nbut the actual one found is\n", comment.actual,
                    "\nMake sure you requested files for the proper folder or adjust the message.")
        else ""
    
    if(nzchar(errmsg)) {
        if(interactive == FALSE) stop("Execution stopped")
        message(errmsg)
        FALSE
    } else {
        TRUE
    }    
}

set.course.dir <- function(course.dir) {

    if(!is.empty(course.dir)) {
        course.dir <- no.slash(course.dir)
        if(!dir.exists(course.dir)) stop("Directory does not exist:\n", course.dir)
        else return(course.dir)
    }

    prompt <- paste("Enter the path of the local course dir. If non-exsisting, it will be created.\n",
                    "On Windows use a single backslash (C:\\path): ")

    repeatedask(prompt, "Do you want to retry perhaps with a different name?", "Yes", "No, I want to exit",
                course.dir.test)

}

course.dir.test <- function(course.dir) {
    if(dir.exists(course.dir)) return(TRUE)
    suc <- dir.create(course.dir, showWarnings = FALSE)
    if(!suc) message("Cannot create dir ", course.dir)
    suc
}
