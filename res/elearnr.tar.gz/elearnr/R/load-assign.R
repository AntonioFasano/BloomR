## The assignment environments
assignment <- new.env()
assignment$nosolenv <- new.env()
assignment$wsolrds <- NULL

#' Load assignment in cloud
#' 
#' Laod assignment with and without solutions and set its send status as active.
#'
#' `set.send.active()` updates the 'expire' file in cloud, setting `sendactive` flag to `TRUE~ or `FALSE` and the time of its update.
#' The `exam.send` function, reads this file, which contains also the exam build, and determines if it could send the data.
#'
#' You can use `get.send.status()` to obtain the exam random build number,
#' the activity flag and the time of the last status update.
#'
#' @param rdata path to RData file
#' @param rds   path to rds file with solutions
#' @param remind a friendly remainder to activate the exam with [`set.send.active()`].
#' @name load-assign
#' @export 
upload.assign <- function( # load assignment in cloud from an RData file
                        rdata,  # path to RData file without solutions 
                        rds,    # path to rds file with solutions
                        remind = TRUE  # a friendly remainder to activate the exam with [`set.send.active()`].
                        ) {
    
    if(!is.setup()) stop("Can't find any course configuration in memory. Did you setup the course with 'setup.course()'",
                         call. = FALSE)
    load(rdata, envir = assignment$nosolenv) # load from file to env
    if(is.null(assignment$nosolenv$.assignment)) stop("The file does not appear to be a student assignment:\n", rdata)
    bindata <- new.nosolRData() # serial/compress similar to RData    
    cloud.write.file.unsafe(bindata, elearnrEnv$config$nosolRData)
    assignment$wsolrds <- readRDS(rds)
    if(is.null(assignment$wsolrds$values)) stop("The file does not appear to be a solution assignment:\n", rds)
    bindata <- new.wsol.rds() # serial/compress indentical to rds format
    cloud.write.file.unsafe(bindata, elearnrEnv$config$wso)
    exam.rnd.build <- binDecompress(bindata)$exam.rnd.build    
    set.exam.build(exam.rnd.build)
    if(remind)  message("Don't forget to activate the exam with:\n\nset.send.active()")
}

#' @param on if `TRUE`/`FALSE` the remote `sendactive` flag is updated accordingly.
#' @name load-assign
#' @export
set.send.active <- function(on = TRUE) {
    if(!is.setup()) stop("Can't find any course configuration in memory. Did you setup the course with 'setup.course()'",
                         call. = FALSE)
    bindata <- pcloudr::pcloud.read(elearnrEnv$config$expire.bin) # read data to get exam.rnd.build
    status <- binDecompress(bindata)
    status$sendactive = on
    status$updated = Sys.time()    
    bindata <- binCompress(status)    
    cloud.write.file.unsafe(bindata, elearnrEnv$config$expire.bin)
}

#' @return The only function to return non-null data is `get.send.status`, which give a list with the exam random build number,
#'         the active-send status and the last time the status was updated.
#' @name load-assign
#' @export
get.send.status <- function(on = TRUE) {

    if(!is.setup()) stop("Can't find any course configuration in memory. Did you setup the course with 'setup.course()'",
                         call. = FALSE)
    bindata <- pcloudr::pcloud.read(elearnrEnv$config$expire.bin) # read data to get exam.rnd.build
    binDecompress(bindata)

}


set.exam.build <- function(build) { # initialise the expiration file with the exam build
    bindata <- binCompress(list(exam.rnd.build = build, sendactive = FALSE, updated = Sys.time()))
    cloud.write.file.unsafe(bindata, elearnrEnv$config$expire.bin)
}

new.nosolRData <- function() { # create RData-like content from enviromment
    ## similar not equal to a file RData 
    binCompress(assignment$nosolenv)
}

new.wsol.rds <- function() { # create rds content from enviromment
    ## identical to a file rds
    binCompress(assignment$wsolrds)    
}




