#' Remote Paths
#'
#' If you comply with the procedure detailed in `authoriseme()`, 
#' when you are required to enter pCloud remote paths by  elearnr functions, for example [`setup.course()`],
#' the remote root (`/`) is relative to a specific pCloud-assigned folder.    
#' This is a security feature resulting from setting the private folder option in pCloud
#' (see point 2 in [`authoriseme()`] 'Details').
#'  
#' The path of the pCloud-assigned folder is `/Applications/elearnr`,
#' unless during the authorisation you used an app name other than 'elearnr'.
#' Put it another way, this is the only cloud folder elearnr can read and write,
#' therefore the actual cloud path `/Applications/elearnr/my-course-upload` is seen by elearnr simply as `/my-course-upload`.
#' @seealso [`authoriseme()`]

#' @name remote-paths
NULL


#' Authorise elearnr
#'
#' Interactive procedure to authorise elearnr on 'pCloud.com'.
#'
#' Authorisation is a one-off procedure, that allows elearnr to have a limited access (based on OAuth2) to
#' the free cloud storage service [https://pcloud.com](https://pcloud.com).
#'  
#' The first part of the authorisation  happens on the pCloud website.
#' 1. Sign up if necessary and sign in to
#' [https://docs.pcloud.com/my_apps/](https://docs.pcloud.com/my_apps/) (trailing `/` is necessary).
#'
#' 2. Create a new app, perhaps named `elearnr`, setting `Folder access` to `Private` and `Write access` to `Yes`.
#'  
#' 3. After creating the app, click on its link, to edit settings, and:
#'     1. disallow 'implicit grant';
#'     2. add one or more redirect URLs, such as `http://localhost:12345`, where the number should be in the range 1,024-65,535(*);
#'     3. take note of the _Client ID_,  _Client secret_  and the used number(s);
#'     4. Save, and check that your settings are actually stored (recommended). 
#'     
#' (*) Adding more  URLs reduces the risk that  the used numbers (aka port numbers) are taken.
#'  
#' To authorise elearnr in R, use:
#' 
#' `authoriseme(client.id, client.secret, ports)`
#'
#' where the arguments are those in Step 3.c above.
#' elearnr will open the pCloud website for confirmation and ask for a password in order
#' to save your pCloud access data to the encrypted file `~/pcloudr`.
#'  
#' If you want to set specific security requirements for your encryption password or get more (customisation) information
#' about the procedure, use `vignette("pcloudr")`, to consult the vignette of the package `pcloudr` and
#' its function `pcloudr::pcloud.auth()`, which is essentially equivalent to `authoriseme()`.
#'
#' **Note**. As result of this procedure, elearnr remote root path is mapped to the real pCloud folder `/Applications/elearnr`.
#' This restriction is a security feature. 
#' 
#' @seealso `browseVignettes("pcloudr")` [secretR::pwpolicy()], [pcloudr::pcloud.config()]
#' 
#' @param client.id the app client identification issued at registration.
#' @param client.secret the app client secret issued at registration.
#' @param ports a numeric vector of the redirect ports set during the app registration.
#'        A port is the `xxxx` component in the `http://localhost:xxxx` redirect URLs.
#' @param ... more arguments required by `pcloudr::pcloud.auth()`. 
#' @return logical value for success.
#' @name authorise
#' @export
authoriseme <- function( # Authorise elearnr with pCloud
                         client.id, client.secret, ports,
                         ...
                         ) {

    pcloudr::pcloud.auth(client.id = client.id, client.secret = client.secret, ports = ports, ...)

}
 
# LocalWords:  elearnr OAuth2 pCloud
