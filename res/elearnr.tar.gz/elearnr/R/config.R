elearnrEnv <- new.env()
elearnrEnv$confile <- NULL
elearnrEnv$config <- NULL

#' Configuration
#'
#' `read.conf()` and `write.conf()` resp. reads and writes the package configuration file `~/elearnr.conf`,
#' unless an alternative argument is passed. You are not supposed to write the file and the function can be removed in the future.
#' If you really want to, run `read.conf()` immediately after, to keep memory consistence.
#' `is.setup()` can be useful in scripts to know if a course has been setup and its configuration loaded in memory.
#'
#' Configuration lines, should be R assignments such as `key = val`. Full or inline comments are possible,
#' If a key is assigned twice, the last value is used.
#' Using a non-default path for `confile` has effect only for the current R session.
#'
#' `conflist` is a list whose elements are variables symbols used to populate the configuration file.
#' If a list element is unnamed, the variable symbol and value are added as a key and value, that is
#' `list(var)` is added as `var = 123`, assuming that `123` is `var` value.
#' For a named list element, the name is considered as the variable to store, while the element value is used as a comment,
#' thus `list(var = "some comment")` is added as `var = 123 # some comment`.
#' Comments are added inline, unless they start with one or more newlines,
#' in which case they are written above the configuration line.
#'
#' **NOTE** The package configuration file, `confile`, is intended to store instructor related data.
#' For students the file returned by [`.exam.enrol.file()`] is used, which can be read with [`exam.show.enrol()`].
#' 
#' @param confile the package onfiguration file path.
#' @return `read.conf()`: a list whose names/values are the configuration file keys/values, which is also stored in memory.
#' @name configure
#' @export
read.conf <- function(# Read the package configuration file
                      confile = "~/elearnr.conf" # path to configuration file
                      ) { 

    if(!file.exists(confile))
        stop("Can't find the package configuration file. Did you setup the course with 'setup.course()'", call. = FALSE)
    
    lines <- tryCatch(parse(confile), error = function(e) e)
    ## Stop on parse error 
    if(inherits(lines, "error"))
        stop("while parsing elearnr configuration file, ", lines$message, call. = FALSE)


    ## Stop on non-assigments lines
    mapply(is.conf.assign, lines, seq_along(lines))


    ## Get keys/values
    keys <- lapply(lines, `[[`, 2) |> sapply(FUN = deparse)
    values <- lapply(lines, `[[`, 3) 
    conf <- setNames(values, keys)

    ## No dupes
    dups <- duplicated(keys, fromLast = TRUE)
    elearnrEnv$config <- conf[!dups]
    elearnrEnv$confile <- confile
    elearnrEnv$config
}

#' @return `read.conf()`: `TRUE` when a course configuration data is found in memory else otherwise.
#' @name configure
#' @export
is.setup <- function() { # returns `TRUE` when a course has been setup and its configuration data is found in memory. 

    is.set <- !is.null(elearnrEnv$config)
    #warm <- paste0("Memory configuration is inconsistent with the package configuration file.",
    #               "\nThe best would to restart with:\n\n",
    #               "detach(elearnr, unload = TRUE) \nlibrary(\"elearnr\"") 

    is.set
}

is.conf.assign <- function(lineexp, nline) { # test if a parsed conf line is an R assignment 

    linestr <- deparse(lineexp)

    ## test length
    if(length(lineexp) < 3)      conferr("missing right-value assignment", nline, linestr)
    else if(length(lineexp) > 3) conferr("just use a simple assignment, such as 'key = value'", nline, linestr)

    ## test for assign operator
    op <- lineexp[[1]]
    op.s <- deparse(op)
    if(mode(op) != "name" || !op.s %in% c('=', '<-'))
        conferr(paste(sQuote(op.s, q = FALSE), "should be replaced by an assignment operator"), nline, linestr)

    ## test LHS
    left <- lineexp[[2]]
    left.s <- sQuote(deparse(left), q = FALSE)
    if(mode(left) != "name") conferr(paste(left.s, "should be replaced by a variable"), nline, linestr)

    ## test RHS
    types <- c("numeric", "logical", "character", "NULL")
    types.s <- paste(sQuote(types, q = FALSE) , collapse = ", ")    
    right <- lineexp[[3]]
    right.s <- sQuote(deparse(right), q = FALSE)
    if(! mode(right) %in% types)
        conferr(paste(right.s, "should be in", types.s), nline, linestr)
}

conferr <- function(  # stop with given error
                    errmsg, # colon added, start lowcase
                    nline,
                    line
                    ) {

    stoperr <- paste0("In ", elearnrEnv$confile, " line ", nline, ", ", errmsg, "\n", line)    
    stop(stoperr, call. = FALSE)
}

#' @param conflist list with the variables to add to the configuration file. See details.
#' @return `write.conf()`: is used only for its side effect. 
#' @name configure
#' @export
write.conf <- function( # Write the package configuration file
                       conflist, # list with the variables to add to the configuration file. See details.
                       confile = "~/elearnr.conf" # path to configuration file
                       ) {
    if(!is.list(conflist)) stop("'conflist' is not a list")

    callenv <- parent.frame() 
    vars <- substitute(conflist)[-1] # 1 is for list() token
    lnames <- names(conflist)
    linecom <- incom <- ""

    conflines <- sapply(seq_along(vars), function(i) {

        ## list(var)
        if(lnames[i] == "") {
            key <- deparse(vars[[i]])
            value <- deparse(conflist[[i]])
            
        ## list(var = comment)
        } else {
            comm <- conflist[[i]]
            key <- lnames[i]
            value <- deparse(get(key, pos = callenv))
            if(grepl("^\n", comm)) linecom <- sub("(\n+)(.+)", "\\1## \\2\n", comm)
            else incom <- paste0(" # ", comm)
        }
        
        paste0(linecom, key, " = ", value, incom)
    })

    ## conftext <- paste(conflines, collapse = "\n")
    writeLines(conflines, confile)
}
