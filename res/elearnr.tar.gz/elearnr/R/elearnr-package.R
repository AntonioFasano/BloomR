#' Classroom R Test
#'
#' Deliver R tests via a cloud folder, collect results and grade them.
#'
#' Currently the cloud folder is based on pCloud.
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats setNames
## usethis namespace: end
NULL
