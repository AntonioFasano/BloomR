### Cloud (and local) filesystem objects
cloud.really.delete <- function( #  ask dobule confirmation to delete a file or a non-empty folder
                                path, # full-path with respect to app cloud visibility  
                                type  # 'folder' or 'file'
                         ) {

    if(! type %in%  c('folder',  'file')) stop("The 'type' for the object to delete should be 'folder' or 'file'")
    delask <- if(type == 'file') {
                 pcloudr::pcloud.exists.file(remote.path = path)
             } else {
                 pcloudr::pcloud.exists.folder(remote.path = path) && !pcloudr::pcloud.folder.empty(remote.path = path)
             }
    if(delask) {
        if(! really.sure(paste("The", type, path, "exists non-empty. Do you want to delete it.")))
            stop("Stopped by user", call. = FALSE)

        if(type == 'file') {
            pcloudr::pcloud.delete.file(remote.path = path)
            err <- pcloudr::pcloud.exists.file(remote.path = path)
        } else {
            pcloudr::pcloud.delete.folderrec(remote.path = path)
            err <- pcloudr::pcloud.exists.folder(remote.path = path)
        }
        
        if(err) stop("There was an error while deleting the ", type, " ", path)
    }
}

cloud.create.folder.safe <- function( #  create a folder in cloud and double-confirm delete
                                path # full-path with respect to app cloud visibility  
                                ) {
    cloud.really.delete(path, type = 'folder')
    resp <- pcloudr::pcloud.createfolderifnotexists(remote.path = path)
    if(!pcloudr::pcloud.exists.folder(remote.path = path)) stop("There was an error while creating folder ", path)    
}

cloud.write.file.safe <- function( #  create a file in cloud and double-confirm delete
                             path, # full-path with respect to app cloud visibility
                             data # data to write
                             ) {

    cloud.really.delete(path, type = 'file')
    resp <- pcloudr::pcloud.write(data, remote.path = path)
    if(!pcloudr::pcloud.exists.file(remote.path = path)) stop("There was an error while writing file ", path)    
}

cloud.write.file.unsafe <- function( #  create a file in cloud and double-confirm delete
                             data, # data to write
                             path  # full-path with respect to app cloud visibility
                             ) {

    resp <- pcloudr::pcloud.write(data, remote.path = path)
    if(!pcloudr::pcloud.exists.file(remote.path = path)) stop("There was an error while writing file ", path)    
}


binCompress <- function(robj) { # compress any R object
    memCompress(serialize(robj, connection = NULL), "gzip")    
}

binDecompress <- function(binobj) { # drcompress an object compressed by binCompress()
    unserialize(memDecompress(binobj, "gzip"))
}


no.slash <- function(path) { # remove trailing slash

    path <-   sub("/+$", "", path)
    sub("\\\\+$", "", path)
    
}
