#' Grade exams 
#' 
#' `download.exams()` downloads the exam-upload dir to a time-named directory inside the local course directory.
#' `grade.exams` produces grading files in the same directory.
#'
#' The exam-upload dir and the local course directory are stored in `
#' elearnrEnv$config$updir` and `elearnrEnv$config$course.locdir`.
#' RDS exam are store in the `sent` sub-directory.
#'
#' Grading file are `results.txt` and `results.csv`, with summary data in text and CSV format,
#' and `details.txt` with summary detailed text data.
#' 
#' @name grading
#' @export 
download.exams <- function() { # Download the exam-upload dir to a time-named directory inside the local course directory
    exams <- pcloudr::pcloud.listfolderfileids.rec(elearnrEnv$config$updir, suffix = TRUE)
    examlist <- lapply(seq_along(exams), \(i) exams[i]) 

    ddir <- file.path(elearnrEnv$config$course.locdir, isotime())
    sent <- file.path(ddir, "sent")
    dir.create(sent, recursive = TRUE)
    lapply(examlist, function(exam) {
        message(strsplit(exam,   "-")[[1]][])
        fpath <- file.path(sent, paste0(exam, ".rds"))
        bindata <- pcloudr::pcloud.read(fileid = names(exam), verify = TRUE)
        saveRDS(binDecompress(bindata), fpath)
        })
    fpath <- file.path(ddir, "exam-wsol.rds")
    bindata <- pcloudr::pcloud.read(elearnrEnv$config$wsol.rds, verify = TRUE)
    saveRDS(binDecompress(bindata), fpath)

    message("Data downloaded in:\n", ddir)
    invisible(TRUE)

}

#' @name grading
#' @export 
grade.exams <- function() {
    
    ## init grading
    crc$score <- NULL
    examdir <- last.download()
    details.txt <- file.path(examdir, "details.txt")
    if(file.exists(details.txt)) file.remove(details.txt) 

    crc$sol <- last.download.wsolrds()      
    lapply(last.download.exams(), grade.exam)
                                        # crc$score
    
    results.txt <- file.path(examdir, "results.txt")
    results.csv <- file.path(examdir, "results.csv")
    utils::write.csv(crc$score, file = results.csv)
    sep <- " | "
    writeLines(apply(crc$score, 1, paste, collapse = sep), results.txt)
    invisible(TRUE)

    message("Grade files in:\n", examdir)

}


last.download <- function() { # Get full-path of the last dowloaded exams dir.
### Dir names are time based, and only those starting with 4 digits and dash are considered

    cdir <- elearnrEnv$config$course.locdir
    ## start with 4 digits and dash
    gooddirs <- grep("^[[:digit:]]{4,4}-", dir(cdir), value = TRUE)
    if(!length(gooddirs)) stop("No time-based subs in course dir:\n", cdir)
    lastsub <- gooddirs[length(gooddirs)] 
    file.path(cdir, lastsub)

}

last.download.exams <- function() { # Get 'sent/*' files in last.download()

    lastsub <- last.download()
    sent <- file.path(lastsub, "sent")
    exams <- dir(sent)
    if(!length(exams)) {
        stop("There are no sent exams in the last downloaded dir:\n", sent)
        return(invisible(FALSE))
    }
    file.path(sent, exams)
}

last.download.wsolrds <- function() { # Get exam-wsol.rds in last.download()
    examdir <- last.download()
    readRDS(file.path(examdir, "exam-wsol.rds"))
}

grade.exam <- function(current.exam) {

    stud <- readRDS(current.exam)
    sol <- crc$sol
    
    ## Student
    tee("=============")
    tee(paste(stud$.student[c("givenname", "familyname")], collapse = " "))

    ## Var names
    out("Vars   Due: ", pc(names(sol$values)), "  Yours: ", pc(names(stud$values)))
    out("   ", flat(check.names(sol$values, stud$values)))

    ## Var classes
    out("Classes   Due: ", flat(class.v(sol$values)), "  Yours: ", flat(class.v(stud$values)))
    out("   ", flat(check.classes(stud$values, sol$classes)))
    
    ## Var values
    out("Values   Due: ", flat(lapply(sol$values, function(val) pc(heads(val)))),
        "  Yours: ", flat(lapply(stud$values, function(val) pc(heads(val)))))
    res <- check.values(sol$values, stud$values)
    out("   ", flat(check.values(sol$values, stud$values)))
                
    ## Passed
    passed <- length(which(res))
    tee(paste("Passed:", passed))
    with(stud, add.score(.student$givenname, .student$familyname, .student$email, passed = passed))
    #NULL
       
}

### Correction environment
crc <- new.env()
crc$add.score <- NULL
crc$sol <- NULL  # the solved RDS 
environment(grade.exam) <- crc  # make helpers visible by grading functions

## Console and file output 
crc$tee <- function(...) { # write to console and to assessment file
    crc$out(...)
    message(...)
}
crc$out = function(...) { # write to assessment file lapply(substitute(...()), eval)
    examdir <- last.download()
    details.txt <- file.path(examdir, "details.txt")
    write(paste(...), file = details.txt, append = TRUE)
}
environment(crc$out) <- crc # make helpers' helpers visible 

## Checks
crc$check.names <- function(result.prof, result.stud)
    sapply(names(result.prof), function(nm) !is.null(result.stud[[nm]]))

crc$check.classes <- function(result.stud, classes)
    sapply(names(result.stud), function(nm) isTRUE(classes[[nm]] == class(result.stud[[nm]])))

crc$check.values <- function(result.prof, result.stud)
    sapply(names(result.prof), function(nm) isTRUE(all.equal(result.prof[[nm]], result.stud[[nm]])))

crc$class.v <- function(vec) sapply(vec, class)

crc$pc <- function(...) paste(..., collapse=", ")
crc$flat <- function(named.vec) pc(paste(names(named.vec), named.vec))
environment(crc$flat) <- crc # make helpers' helpers visible 

crc$heads <- function(veclist) round(sapply(veclist, head, 5), 4)

crc$add.score <- function(givenname, familyname, email, passed){ ## Add score to global environemnt var
    score <- data.frame(
        givenname =givenname, familyname = familyname, email = email, passed = passed)
    crc$score <- rbind(crc$score, score)
}

##---end Correction environment





