### Syntax enhancements

# until <- function(expr) { # Repeat until the expression is non-NULL
# ### if expr is NA, it could be considered as an error, failed test, etc.
#     unevalled <- substitute(expr)
#     repeat {
#         ret <- eval(unevalled, envir=parent.frame(n = 1))
#         if(!is.null(ret)) break
#     }
#     ret
# }

isNA <- function(expr) length(expr) == 1 && is.na(expr)
notNA <- function(expr) !isNA(expr)
is.empty <- function(var) is.null(var) || !nzchar(var) ## short for NULL or zero-string
                        
ask <- function(quest = NULL, ansvec = c("Yes", "No")) {
    utils::menu(ansvec, title = quest)
}

repeatedask <- function(ask, errmsg, redo, exit, succ.cond, ...) {# 'ask' for input and test it for success via succ.cond callback.
### On success return user input. On failure, show 'errmsg' and give a 'redo' and 'exit' option.
### Depending on the choice, the request is reiterated or execution stopped
### errmsg can be "" and perhaps use succ.cond to show messages. 

    uinput <- trimws(readline(ask))
    if(!nzchar(uinput)) uinput <- repeatedask(ask, errmsg, redo, exit, succ.cond, ...)
    else {
        succ <- do.call("succ.cond", c(uinput, list(...)))
        if(succ) return(uinput)
        if(is.empty(errmsg)) errmsg <- NULL
        choice <- ask(errmsg, c(redo, exit))
        if(choice == 1) {
            uinput <- repeatedask(ask, errmsg, redo, exit, succ.cond, ...)
        } else stop("Stopped by user", call. = FALSE)
    }
    uinput
}

really.sure <- function(quest) { # ask dobule confirmation to quest
    ans <- ask(quest)
    if(ans == 0 || ans == 2) return(FALSE)
    ans <- ask("Are you absolutely sure?", c("Yes, I am absolutely sure.", "No."))    
    if(ans == 0 || ans == 2) return(FALSE)
    TRUE
}
