#' Debug Functions
#'
#' `debug.file.pack()`, `debug.file.enrol()` attach and detach a '.debug' suffix to
#' the [package configuration file][configure] and the [student enrol file][enrol], respectively.
#'
#' When the files to be renamed does not exist the respective  `debug.*` function does nothing.
#'
#' @seealso [Package configuration file][configure],  [Student enrol file][enrol], [.exam.enrol.file()]
#' @param suffix if `TRUE` append the suffix; if `FALSE` remove suffix.
#' @param overwrite overwrite existing file if `TRUE`.
#' @return `TRUE` if a renaming occurred, `FALSE` otherwise.
#' @name debug
#' @export
debug.file.pack <- function( # suffix the package configuration file
                            suffix, # if `TRUE` append the suffix; if `FALSE` remove suffix.
                            overwrite = FALSE # overwrite existing file if `TRUE`
                            ) {

    original <- elearnrEnv$confile
    suffile <- paste0(original, ".debug")

    debug.file(original,suffile, suffix, overwrite) 

}

#' @name debug
#' @export
debug.file.enrol <- function( # suffix the student enrol file 
                             suffix, # if `TRUE` append the suffix; if `FALSE` remove suffix.
                             overwrite = FALSE # overwrite existing file if `TRUE`
                            ) {

    original <- .exam.enrol.file()
    suffile <- paste0(original, ".debug")

    debug.file(original,suffile, suffix, overwrite) 

}

debug.file <- function(original, suffile, suffix, overwrite) {

    remove.suff <- !suffix

    if(suffix) {
        if(!overwrite && file.exists(suffile)) return(FALSE)
        if(file.exists(original)) file.rename(original, suffile) else FALSE 
    }

    else if(remove.suff) {
        if(!overwrite && file.exists(original)) return(FALSE)
        if(file.exists(suffile)) file.rename(suffile, original) else FALSE 
    }

}
