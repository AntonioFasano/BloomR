.onLoad <- function(libname, pkgname) {
    if(file.exists("~/elearnr.conf")) read.conf()
    init.stud.enrol()
    invisible()
}

.onAttach <- function(libname, pkgname) {
    packageStartupMessage("If you are a student, start with 'exam.enrol()' or 'exam.download()'.")
}
