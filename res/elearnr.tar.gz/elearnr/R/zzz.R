.onLoad <- function(libname, pkgname) {
    if(file.exists("~/elearnr.conf")) read.conf()
    init.stud.enrol()
    packageStartupMessage("If you are a student, start with 'exam.enrol()' or 'exam.download()'.")
    invisible()
}
